// Main Application Controller & UI State Router
window.AkshayaNotify = {
  toast: function(msg, type = 'info') {
    var container = document.getElementById('toast-box');
    if (!container) return;

    var toastEl = document.createElement('div');
    toastEl.className = 'toast ' + type;
    toastEl.innerHTML = `
      <span>${type === 'success' ? '✅' : (type === 'warning' ? '⚠️' : (type === 'error' ? '🚨' : 'ℹ️'))}</span>
      <span>${msg}</span>
    `;

    container.appendChild(toastEl);
    setTimeout(() => {
      toastEl.style.opacity = '0';
      toastEl.style.transform = 'translateY(15px)';
      setTimeout(() => toastEl.remove(), 300);
    }, 4000);
  },

  alertModal: function(title, message) {
    var modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    modalContainer.innerHTML = `
      <div style="position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(27,42,65,0.7); z-index:3000; display:flex; align-items:center; justify-content:center; padding:20px; animation:fadeIn 0.2s ease;">
        <div class="card" style="max-width:540px; width:100%; border-top:5px solid var(--primary-saffron); box-shadow:var(--shadow-lg); animation:slide-up 0.25s ease;">
          <div class="card-header">
            <h3 class="card-title">${title}</h3>
            <button onclick="AkshayaNotify.closeModal()" style="background:none; border:none; font-size:22px; cursor:pointer; color:var(--text-muted);">&times;</button>
          </div>
          <div style="font-size:14px; color:var(--text-primary); white-space:pre-wrap; line-height:1.6; margin-bottom:20px;">${message}</div>
          <div style="display:flex; justify-content:flex-end;">
            <button class="btn btn-primary" onclick="AkshayaNotify.closeModal()">
              Understood / Close
            </button>
          </div>
        </div>
      </div>
    `;
  },

  closeModal: function() {
    var modalContainer = document.getElementById('modal-container');
    if (modalContainer) modalContainer.innerHTML = '';
  }
};

window.AkshayaApp = {
  currentRole: 'split', // Default to split-view for immediate demonstration of dual Admin/HQ sync!
  currentLayout: 'split', // 'split', 'admin_full', 'hq_full'
  clientId: 'client-' + Math.random().toString(36).substr(2, 8),
  deferredInstallPrompt: null,

  init: function() {
    var self = this;

    // Check URL params for role or layout overrides
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('role')) {
      this.currentRole = urlParams.get('role');
    }
    if (urlParams.get('layout')) {
      this.currentLayout = urlParams.get('layout');
    }

    // Initialize Storage & Sync
    window.AkshayaStorage.init();
    window.AkshayaSync.init();

    // Subscribe to incoming real-time events across windows & tabs
    window.AkshayaSync.subscribe(function(envelope, isLocal) {
      self.handleRealtimeEvent(envelope, isLocal);
    });

    // PWA Install Prompt Listener
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      self.deferredInstallPrompt = e;
      var installBtn = document.getElementById('btn-pwa-install');
      if (installBtn) installBtn.style.display = 'inline-flex';
    });

    // Initial Render
    this.render();
  },

  setRole: function(role) {
    this.currentRole = role;
    if (role === 'admin') this.currentLayout = 'admin_full';
    else if (role === 'hq') this.currentLayout = 'hq_full';
    
    var roleName = window.AkshayaI18n.t('role_' + role);
    window.AkshayaNotify.toast(`Switched perspective to: ${roleName}`, "info");
    this.render();
  },

  setLayout: function(layout) {
    this.currentLayout = layout;
    if (layout === 'split') {
      this.currentRole = 'split';
    } else if (layout === 'admin_full') {
      this.currentRole = 'admin';
    } else if (layout === 'hq_full') {
      this.currentRole = 'hq';
    }
    this.render();
  },

  handleRealtimeEvent: function(envelope, isLocal) {
    switch(envelope.type) {
      case 'REPORT_SUBMITTED_HQ':
        if (!isLocal) {
          window.AkshayaNotify.toast(`🔔 Real-Time Update: New Daily Operations Report submitted to Headquarters!`, "success");
          window.AkshayaDemoBar.playEmergencyBeep();
        }
        break;
      case 'REPORT_ACKNOWLEDGED_HQ':
        if (!isLocal) {
          window.AkshayaNotify.toast(`✓ Headquarters formally acknowledged Report #${envelope.payload.reportId}!`, "success");
        }
        break;
      case 'WORKER_CHECKIN':
        if (!isLocal) {
          window.AkshayaNotify.toast(`📍 Real-Time Telemetry: Worker ${envelope.payload.workerName} checked in via GPS Selfie.`, "info");
        }
        break;
      case 'SHORTAGE_REPORTED':
        if (!isLocal) {
          window.AkshayaNotify.toast(`⚠️ Shortage Alert: ${envelope.payload.shortageKg} kg reported on ${envelope.payload.school || 'Route'}.`, "warning");
        }
        break;
      case 'CRITICAL_ALERT':
        if (!isLocal) {
          window.AkshayaDemoBar.playEmergencyBeep();
          window.AkshayaNotify.alertModal(
            "🚨 CRITICAL ALARM DISPATCHED ACROSS TERMINALS",
            `Ticket #${envelope.payload.id} received from ${envelope.payload.schoolName}!\nSafety review in progress.`
          );
        }
        break;
    }
    this.render();
  },

  promptPWAInstall: function() {
    if (this.deferredInstallPrompt) {
      this.deferredInstallPrompt.prompt();
      this.deferredInstallPrompt.userChoice.then((choiceResult) => {
        if (choiceResult.outcome === 'accepted') {
          window.AkshayaNotify.toast("Akshaya Seva Connect installed as PWA app!", "success");
        }
        this.deferredInstallPrompt = null;
      });
    } else {
      window.AkshayaNotify.alertModal(
        "📱 Progressive Web App (PWA) Ready",
        `Akshaya Seva Connect is fully PWA enabled!\n\nTo install on your mobile phone or desktop:\n1. On Android/Chrome: Tap Chrome menu ⋮ -> 'Install app' or 'Add to Home screen'\n2. On iPhone/Safari: Tap Share 📤 -> 'Add to Home Screen'\n\nEnables 100% offline access, camera integration, and instant push alerts!`
      );
    }
  },

  render: function() {
    var root = document.getElementById('app-root');
    if (!root) return;

    var role = this.currentRole;
    var layout = this.currentLayout;
    var t = window.AkshayaI18n.t.bind(window.AkshayaI18n);

    root.innerHTML = `
      <!-- Demo Controls Banner -->
      <div id="demo-bar-mount">
        ${window.AkshayaDemoBar.render()}
      </div>

      <!-- Main Header -->
      <header class="main-header">
        <div class="logo-container" onclick="AkshayaApp.setLayout('split')">
          <div class="brand-symbol">ॐ</div>
          <div class="brand-text">
            <h1>${t('appName')}</h1>
            <p>${t('appTagline')}</p>
          </div>
        </div>

        <div class="header-right">
          <!-- Network Status Chip -->
          <div id="network-status-badge" class="status-chip online">
            <span class="status-dot green"></span>
            <span class="badge-text">Online</span>
          </div>

          <!-- PWA Install Button -->
          <button id="btn-pwa-install" class="btn btn-outline" style="padding:6px 12px; font-size:12px;" onclick="AkshayaApp.promptPWAInstall()">
            📱 Install App
          </button>

          <!-- Current Perspective Badge -->
          <div class="role-badge" onclick="AkshayaApp.showRolePicker()">
            Perspective: <strong>${t('role_' + role) || 'Dual Split Sync'}</strong> ▾
          </div>
        </div>
      </header>

      <!-- App Main Layout -->
      <div class="app-layout">
        <!-- Desktop Sidebar -->
        <aside class="sidebar">
          <div style="font-size:11px; text-transform:uppercase; color:var(--text-muted); font-weight:700; margin-bottom:8px; padding-left:8px;">
            Operations Modules
          </div>

          <a class="sidebar-nav-item ${layout === 'split' ? 'active' : ''}" onclick="AkshayaApp.setLayout('split')">
            <span>🔀</span> <span>Dual Sync (Admin + HQ)</span>
          </a>
          <a class="sidebar-nav-item ${role === 'admin' ? 'active' : ''}" onclick="AkshayaApp.setRole('admin')">
            <span>🏢</span> <span>Admin Operations</span>
          </a>
          <a class="sidebar-nav-item ${role === 'hq' ? 'active' : ''}" onclick="AkshayaApp.setRole('hq')">
            <span>🏛️</span> <span>Headquarters (HQ)</span>
          </a>
          <a class="sidebar-nav-item ${role === 'worker' ? 'active' : ''}" onclick="AkshayaApp.setRole('worker')">
            <span>👨‍🍳</span> <span>Worker GPS Attendance</span>
          </a>
          <a class="sidebar-nav-item ${role === 'driver' ? 'active' : ''}" onclick="AkshayaApp.setRole('driver')">
            <span>🚚</span> <span>Driver Route & Shortage</span>
          </a>
          <a class="sidebar-nav-item ${role === 'school' ? 'active' : ''}" onclick="AkshayaApp.setRole('school')">
            <span>🏫</span> <span>School Acknowledgement</span>
          </a>
          <a class="sidebar-nav-item ${role === 'supervisor' ? 'active' : ''}" onclick="AkshayaApp.setRole('supervisor')">
            <span>📋</span> <span>Supervisor & Hygiene Audit</span>
          </a>
          <a class="sidebar-nav-item ${role === 'supplier' ? 'active' : ''}" onclick="AkshayaApp.setRole('supplier')">
            <span>🌾</span> <span>Supplies & Inward QC</span>
          </a>
          <a class="sidebar-nav-item ${role === 'public' ? 'active' : ''}" onclick="AkshayaApp.setRole('public')">
            <span>📢</span> <span>Public Grievances & SLA</span>
          </a>
        </aside>

        <!-- Main Workspace -->
        <main class="main-content">
          ${this.renderMainContent()}
        </main>
      </div>

      <!-- Mobile Bottom Navigation (4-5 Primary Tabs) -->
      <nav class="mobile-bottom-nav">
        <div class="mobile-nav-items">
          <div class="mobile-nav-item ${layout === 'split' ? 'active' : ''}" onclick="AkshayaApp.setLayout('split')">
            <span style="font-size:18px;">🔀</span>
            <span>Sync</span>
          </div>
          <div class="mobile-nav-item ${role === 'worker' ? 'active' : ''}" onclick="AkshayaApp.setRole('worker')">
            <span style="font-size:18px;">👨‍🍳</span>
            <span>Worker</span>
          </div>
          <div class="mobile-nav-item ${role === 'driver' ? 'active' : ''}" onclick="AkshayaApp.setRole('driver')">
            <span style="font-size:18px;">🚚</span>
            <span>Driver</span>
          </div>
          <div class="mobile-nav-item ${role === 'school' ? 'active' : ''}" onclick="AkshayaApp.setRole('school')">
            <span style="font-size:18px;">🏫</span>
            <span>School</span>
          </div>
          <div class="mobile-nav-item ${role === 'admin' ? 'active' : ''}" onclick="AkshayaApp.setRole('admin')">
            <span style="font-size:18px;">🏢</span>
            <span>Admin</span>
          </div>
        </div>
      </nav>

      <!-- Floating Action Button (FAB) -->
      <button class="fab-btn" onclick="AkshayaApp.handleFabClick()" title="Quick Action">
        ${this.getFabIcon()}
      </button>

      <!-- Toast Container -->
      <div id="toast-box" class="toast-container"></div>

      <!-- Modal Container -->
      <div id="modal-container"></div>
    `;

    window.AkshayaStorage.updateNetworkBadge();
  },

  renderMainContent: function() {
    if (this.currentLayout === 'split') {
      return window.AkshayaSplitView.render();
    }
    switch(this.currentRole) {
      case 'worker': return window.AkshayaWorkerView.render();
      case 'driver': return window.AkshayaDriverView.render();
      case 'school': return window.AkshayaSchoolView.render();
      case 'supervisor': return window.AkshayaSupervisorView.render();
      case 'supplier': return window.AkshayaSupplierView.render();
      case 'admin': return window.AkshayaAdminView.render();
      case 'hq': return window.AkshayaHQView.render();
      case 'public': return window.AkshayaComplaintView.render();
      default: return window.AkshayaSplitView.render();
    }
  },

  getFabIcon: function() {
    switch(this.currentRole) {
      case 'worker': return '📸';
      case 'driver': return '⚠️';
      case 'school': return '✍️';
      case 'supervisor': return '🧼';
      case 'public': return '📝';
      default: return '⚡';
    }
  },

  handleFabClick: function() {
    switch(this.currentRole) {
      case 'worker':
        window.AkshayaWorkerView.startCamera();
        break;
      case 'driver':
        window.AkshayaDriverView.scrollToShortage();
        break;
      case 'school':
        window.AkshayaSchoolView.clearSignature();
        window.AkshayaNotify.toast("Signature canvas ready", "info");
        break;
      case 'supervisor':
        window.AkshayaSupervisorView.showAddAuditModal();
        break;
      case 'public':
        window.AkshayaComplaintView.setTab('raise');
        break;
      default:
        window.AkshayaDemoBar.simulateGenerateReportHQ();
        break;
    }
  },

  showRolePicker: function() {
    var select = document.getElementById('demo-role-select');
    if (select) select.focus();
  }
};

window.renderApp = function() {
  window.AkshayaApp.render();
};

// Bootstrap application on DOM load
document.addEventListener('DOMContentLoaded', function() {
  window.AkshayaApp.init();
});
