// Admin / Management Dashboard: KPIs, Interactive Map, Employee Directory & Reports Center
window.AkshayaAdminView = {
  activeAdminTab: 'dashboard', // 'dashboard', 'map', 'users', 'reports'
  stateFilter: 'Karnataka',
  kitchenFilter: 'all',

  render: function() {
    return `
      <div class="single-panel-layout">
        <!-- Sub Navigation -->
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:10px;">
          <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn ${this.activeAdminTab === 'dashboard' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaAdminView.setTab('dashboard')">
              📊 Live Executive KPIs
            </button>
            <button class="btn ${this.activeAdminTab === 'map' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaAdminView.setTab('map')">
              🗺️ Interactive Operations Map
            </button>
            <button class="btn ${this.activeAdminTab === 'users' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaAdminView.setTab('users')">
              👥 Employee Master Directory (${window.AkshayaData.workers.length + window.AkshayaData.drivers.length})
            </button>
            <button class="btn ${this.activeAdminTab === 'reports' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaAdminView.setTab('reports')">
              📑 Reports Center & Exports
            </button>
          </div>

          <!-- Quick Filters -->
          <div style="display:flex; gap:8px; align-items:center;">
            <select class="form-select" style="width:auto; font-size:13px; padding:6px 10px;" onchange="AkshayaAdminView.filterKitchen(this.value)">
              <option value="all">All 3 Kitchen Hubs</option>
              <option value="K1">BLR-01 (Bengaluru Central)</option>
              <option value="K2">HBL-02 (Hubballi-Dharwad)</option>
              <option value="K3">MYS-03 (Mysuru Rural)</option>
            </select>
          </div>
        </div>

        <!-- View Body -->
        ${this.activeAdminTab === 'dashboard' ? this.renderDashboardTab() : ''}
        ${this.activeAdminTab === 'map' ? this.renderMapTab() : ''}
        ${this.activeAdminTab === 'users' ? this.renderUsersTab() : ''}
        ${this.activeAdminTab === 'reports' ? this.renderReportsTab() : ''}
      </div>
    `;
  },

  setTab: function(tab) {
    this.activeAdminTab = tab;
    if (window.renderApp) window.renderApp();
  },

  filterKitchen: function(kId) {
    this.kitchenFilter = kId;
    window.AkshayaNotify.toast(`Filtered dashboard for ${kId === 'all' ? 'All Kitchens' : kId}`, "success");
    if (window.renderApp) window.renderApp();
  },

  renderDashboardTab: function() {
    var kitchens = window.AkshayaData.kitchens;
    var filtered = this.kitchenFilter === 'all' ? kitchens : kitchens.filter(k => k.id === this.kitchenFilter);
    var totalFed = filtered.reduce((acc, k) => acc + k.currentFedToday, 0);

    return `
      <div>
        <!-- KPI Tiles -->
        <div class="kpi-grid">
          <div class="kpi-card" style="border-left: 4px solid var(--primary-saffron);">
            <div class="kpi-header">
              <span class="kpi-title">Children Fed Today</span>
              <div class="kpi-icon" style="background:#FFF5EB; color:#F28C28;">🧒</div>
            </div>
            <div class="kpi-val">${totalFed.toLocaleString()}</div>
            <div class="kpi-sub positive">↑ 97.4% of Daily Enrolled Target</div>
          </div>

          <div class="kpi-card" style="border-left: 4px solid var(--accent-green);">
            <div class="kpi-header">
              <span class="kpi-title">Food Delivered (kg)</span>
              <div class="kpi-icon" style="background:#E8F5EE; color:#1F7A4D;">🍲</div>
            </div>
            <div class="kpi-val">14,850 kg</div>
            <div class="kpi-sub positive">Core Temp > 65°C Maintained</div>
          </div>

          <div class="kpi-card" style="border-left: 4px solid var(--status-amber);">
            <div class="kpi-header">
              <span class="kpi-title">Food Shortage Rate</span>
              <div class="kpi-icon" style="background:#FEF3C7; color:#D97706;">⚠️</div>
            </div>
            <div class="kpi-val">0.18 %</div>
            <div class="kpi-sub positive">Within 0.5% tolerance threshold</div>
          </div>

          <div class="kpi-card" style="border-left: 4px solid var(--accent-navy);">
            <div class="kpi-header">
              <span class="kpi-title">On-Time Dispatch</span>
              <div class="kpi-icon" style="background:#EEF2F6; color:#1B2A41;">⏱️</div>
            </div>
            <div class="kpi-val">98.8 %</div>
            <div class="kpi-sub positive">Avg Transit Delay: 3.2 mins</div>
          </div>

          <div class="kpi-card" style="border-left: 4px solid #16A34A;">
            <div class="kpi-header">
              <span class="kpi-title">Avg Hygiene Audit</span>
              <div class="kpi-icon" style="background:#DCFCE7; color:#16A34A;">🧼</div>
            </div>
            <div class="kpi-val">91 / 100</div>
            <div class="kpi-sub positive">Green Band Classification</div>
          </div>

          <div class="kpi-card" style="border-left: 4px solid var(--status-red);">
            <div class="kpi-header">
              <span class="kpi-title">Active Complaints</span>
              <div class="kpi-icon" style="background:#FEE2E2; color:#DC2626;">📢</div>
            </div>
            <div class="kpi-val">2 Open</div>
            <div class="kpi-sub negative">1 Critical (SLA Timer Active)</div>
          </div>
        </div>

        <!-- Kitchen Status Grid & Mini Map Preview -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px; margin-bottom:24px;">
          <!-- Kitchens Health Card -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">🏭 Kitchen Production Hub Status</h3>
              <span class="badge badge-green">3 Active Hubs</span>
            </div>

            <div style="display:flex; flex-direction:column; gap:12px;">
              ${filtered.map(k => `
                <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:14px; border-left:4px solid ${k.hygieneRating === 'Green' ? '#16A34A' : '#D97706'};">
                  <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:4px;">
                    <div>
                      <strong style="color:var(--accent-navy); font-size:15px;">${k.name}</strong>
                      <div style="font-size:12px; color:var(--text-secondary);">${k.area}</div>
                    </div>
                    <span class="badge ${k.hygieneRating === 'Green' ? 'badge-green' : 'badge-amber'}">
                      Hygiene: ${k.hygieneScore} / 100
                    </span>
                  </div>

                  <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; margin-top:10px; font-size:12px; background:#FFFFFF; padding:8px; border-radius:4px;">
                    <div><strong>Fed:</strong> ${k.currentFedToday.toLocaleString()} / ${k.dailyCapacity.toLocaleString()}</div>
                    <div><strong>Staff On Duty:</strong> ${k.activeWorkers} present</div>
                    <div><strong>Boiler Temp:</strong> ${k.boilerTemp}</div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Production & Shortage Trend Chart (Pure SVG) -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">📈 7-Day Food Delivered & Shortage Trend</h3>
              <span class="badge badge-navy">Consolidated State Trend</span>
            </div>

            <div style="padding:10px 0;">
              <!-- SVG Bar & Line Chart -->
              <svg viewBox="0 0 420 180" style="width:100%; height:auto;">
                <!-- Grid Lines -->
                <line x1="40" y1="20" x2="400" y2="20" stroke="#E2E8F0" stroke-dasharray="3,3" />
                <line x1="40" y1="60" x2="400" y2="60" stroke="#E2E8F0" stroke-dasharray="3,3" />
                <line x1="40" y1="100" x2="400" y2="100" stroke="#E2E8F0" stroke-dasharray="3,3" />
                <line x1="40" y1="140" x2="400" y2="140" stroke="#E2E8F0" />

                <!-- Days -->
                <text x="70" y="158" font-size="11" fill="#64748B" text-anchor="middle">23 Oct</text>
                <text x="120" y="158" font-size="11" fill="#64748B" text-anchor="middle">24 Oct</text>
                <text x="170" y="158" font-size="11" fill="#64748B" text-anchor="middle">25 Oct</text>
                <text x="220" y="158" font-size="11" fill="#64748B" text-anchor="middle">26 Oct</text>
                <text x="270" y="158" font-size="11" fill="#64748B" text-anchor="middle">27 Oct</text>
                <text x="320" y="158" font-size="11" fill="#64748B" text-anchor="middle">28 Oct</text>
                <text x="370" y="158" font-size="11" fill="#1B2A41" font-weight="700" text-anchor="middle">Today</text>

                <!-- Bars (Food kg in thousands) -->
                <rect x="58" y="45" width="24" height="95" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="108" y="42" width="24" height="98" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="158" y="48" width="24" height="92" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="208" y="40" width="24" height="100" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="258" y="38" width="24" height="102" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="308" y="36" width="24" height="104" rx="3" fill="#F28C28" opacity="0.85" />
                <rect x="358" y="34" width="24" height="106" rx="3" fill="#D67417" />

                <!-- Values -->
                <text x="70" y="38" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">14.1k</text>
                <text x="120" y="35" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">14.3k</text>
                <text x="170" y="41" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">13.9k</text>
                <text x="220" y="33" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">14.5k</text>
                <text x="270" y="31" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">14.6k</text>
                <text x="320" y="29" font-size="10" fill="#1B2A41" font-weight="600" text-anchor="middle">14.7k</text>
                <text x="370" y="27" font-size="10" fill="#D67417" font-weight="700" text-anchor="middle">14.8k</text>
              </svg>
            </div>

            <div style="display:flex; justify-content:center; gap:18px; font-size:12px; color:var(--text-secondary);">
              <span style="display:flex; align-items:center; gap:6px;">
                <span style="width:12px; height:12px; background:#F28C28; border-radius:2px;"></span> Food Delivered (kg)
              </span>
              <span style="display:flex; align-items:center; gap:6px;">
                <span style="width:12px; height:3px; background:#DC2626;"></span> Shortage Tolerance Level (< 0.5%)
              </span>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  renderMapTab: function() {
    var kitchens = window.AkshayaData.kitchens;
    var schools = window.AkshayaData.schools;

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">🗺️ Geographic Operations Command & Geofence Map</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Live tracking of Mega Kitchens, School Centers, Geofencing boundaries, and Delivery Vans.
            </p>
          </div>
          <span class="badge badge-green">GPS Sat-Lock Active</span>
        </div>

        <!-- Interactive SVG Operations Map -->
        <div style="background:#1B2A41; border-radius:var(--radius-md); padding:20px; color:#FFF; position:relative; overflow:hidden;">
          <svg viewBox="0 0 800 450" style="width:100%; height:auto;">
            <!-- Map Base Grid -->
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.05)" stroke-width="1"/>
              </pattern>
            </defs>
            <rect width="800" height="450" fill="#142032" />
            <rect width="800" height="450" fill="url(#grid)" />

            <!-- Connecting Route Lines -->
            <!-- Bengaluru Cluster Routes -->
            <path d="M 400 280 L 340 220 L 450 180" fill="none" stroke="#F28C28" stroke-width="3" stroke-dasharray="6,4" opacity="0.8" />
            <path d="M 400 280 L 470 320 L 530 350" fill="none" stroke="#F28C28" stroke-width="3" stroke-dasharray="6,4" opacity="0.8" />

            <!-- Hubballi Cluster Routes -->
            <path d="M 220 120 L 160 100 L 260 70" fill="none" stroke="#38BDF8" stroke-width="3" stroke-dasharray="6,4" opacity="0.8" />

            <!-- Mysuru Cluster Routes -->
            <path d="M 370 390 L 320 420 L 430 430" fill="none" stroke="#34D399" stroke-width="3" stroke-dasharray="6,4" opacity="0.8" />

            <!-- KITCHEN 1: Bengaluru Central Mega Kitchen -->
            <g transform="translate(400, 280)" style="cursor:pointer;" onclick="AkshayaAdminView.showKitchenDetails('K1')">
              <!-- Geofence 300m circle -->
              <circle r="45" fill="rgba(242, 140, 40, 0.2)" stroke="#F28C28" stroke-width="1.5" stroke-dasharray="4,2" />
              <circle r="16" fill="#F28C28" stroke="#FFF" stroke-width="3" />
              <text x="0" y="5" font-size="14" font-weight="bold" fill="#FFF" text-anchor="middle">🏭</text>
              <text x="0" y="28" font-size="11" font-weight="bold" fill="#FFF" text-anchor="middle">BLR-01 Mega Kitchen</text>
              <text x="0" y="40" font-size="9" fill="#FBBF24" text-anchor="middle">Geofence: 300m</text>
            </g>

            <!-- KITCHEN 2: Hubballi-Dharwad Kitchen -->
            <g transform="translate(220, 120)" style="cursor:pointer;" onclick="AkshayaAdminView.showKitchenDetails('K2')">
              <circle r="40" fill="rgba(56, 189, 248, 0.2)" stroke="#38BDF8" stroke-width="1.5" stroke-dasharray="4,2" />
              <circle r="15" fill="#0284C7" stroke="#FFF" stroke-width="3" />
              <text x="0" y="5" font-size="14" font-weight="bold" fill="#FFF" text-anchor="middle">🏭</text>
              <text x="0" y="28" font-size="11" font-weight="bold" fill="#FFF" text-anchor="middle">HBL-02 Hubballi</text>
              <text x="0" y="40" font-size="9" fill="#38BDF8" text-anchor="middle">Geofence: 250m</text>
            </g>

            <!-- KITCHEN 3: Mysuru Rural Cluster Kitchen -->
            <g transform="translate(370, 390)" style="cursor:pointer;" onclick="AkshayaAdminView.showKitchenDetails('K3')">
              <circle r="42" fill="rgba(244, 63, 94, 0.2)" stroke="#F43F5E" stroke-width="1.5" stroke-dasharray="4,2" />
              <circle r="15" fill="#E11D48" stroke="#FFF" stroke-width="3" />
              <text x="0" y="5" font-size="14" font-weight="bold" fill="#FFF" text-anchor="middle">🏭</text>
              <text x="0" y="28" font-size="11" font-weight="bold" fill="#FFF" text-anchor="middle">MYS-03 Mysuru Hub</text>
              <text x="0" y="40" font-size="9" fill="#F43F5E" text-anchor="middle">Amber (Score: 78)</text>
            </g>

            <!-- Schools / Delivery Points -->
            <!-- S1 Malleshwaram -->
            <g transform="translate(340, 220)" style="cursor:pointer;" onclick="AkshayaAdminView.showSchoolDetails('S1')">
              <circle r="9" fill="#16A34A" stroke="#FFF" stroke-width="2" />
              <text x="14" y="4" font-size="10" fill="#FFF">🏫 S1 Malleshwaram (412 Fed)</text>
            </g>

            <!-- S2 Yeshwanthpur -->
            <g transform="translate(450, 180)" style="cursor:pointer;" onclick="AkshayaAdminView.showSchoolDetails('S2')">
              <circle r="9" fill="#16A34A" stroke="#FFF" stroke-width="2" />
              <text x="14" y="4" font-size="10" fill="#FFF">🏫 S2 Yeshwanthpur (565 Fed)</text>
            </g>

            <!-- S3 Shivajinagar -->
            <g transform="translate(470, 320)" style="cursor:pointer;" onclick="AkshayaAdminView.showSchoolDetails('S3')">
              <circle r="9" fill="#16A34A" stroke="#FFF" stroke-width="2" />
              <text x="14" y="4" font-size="10" fill="#FFF">🏫 S3 Shivajinagar (340 Fed)</text>
            </g>

            <!-- S4 Kengeri -->
            <g transform="translate(530, 350)" style="cursor:pointer;" onclick="AkshayaAdminView.showSchoolDetails('S4')">
              <circle r="9" fill="#F59E0B" stroke="#FFF" stroke-width="2" />
              <text x="14" y="4" font-size="10" fill="#FBBF24">🚚 En Route to Kengeri (ETA 12:35)</text>
            </g>

            <!-- Van Marker on Route 1A -->
            <g transform="translate(370, 250)">
              <rect x="-10" y="-8" width="20" height="16" rx="4" fill="#F28C28" stroke="#FFF" stroke-width="1.5" />
              <text x="0" y="3" font-size="9" fill="#FFF" font-weight="bold" text-anchor="middle">KA01</text>
            </g>
          </svg>

          <!-- Map Legend Bar -->
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; font-size:12px; flex-wrap:wrap; gap:10px;">
            <div style="display:flex; gap:14px;">
              <span>🏭 <strong>Mega Kitchen Hubs</strong> (With GPS Geofence Circles)</span>
              <span>🏫 <strong>Partner Schools</strong> (Confirmed Meals)</span>
              <span>🚚 <strong>Live Delivery Vans</strong> (KA-01-MJ-4521)</span>
            </div>
            <button class="btn btn-outline" style="color:#FFF; border-color:rgba(255,255,255,0.4); padding:4px 10px; font-size:11px;" onclick="AkshayaAdminView.refreshMapPins()">
              🔄 Refresh GPS Ping
            </button>
          </div>
        </div>
      </div>
    `;
  },

  renderUsersTab: function() {
    var workers = window.AkshayaData.workers;
    var drivers = window.AkshayaData.drivers;

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">👥 Employee & Staff Master Directory</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Biometric records, medical fitness certificates, FSSAI training compliance, and real-time attendance.
            </p>
          </div>
          <button class="btn btn-primary" onclick="AkshayaAdminView.showAddWorkerModal()">
            ➕ Register New Employee
          </button>
        </div>

        <div style="overflow-x:auto;">
          <table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;">
            <thead>
              <tr style="background:#F8FAFC; border-bottom:2px solid var(--border-color);">
                <th style="padding:10px;">Employee</th>
                <th style="padding:10px;">Role & Kitchen</th>
                <th style="padding:10px;">Shift</th>
                <th style="padding:10px;">Today's Attendance</th>
                <th style="padding:10px;">Medical Fitness</th>
                <th style="padding:10px;">Food Safety Cert</th>
                <th style="padding:10px; text-align:center;">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${workers.map(w => {
                var isPresent = w.todayAttendance && w.todayAttendance.status === 'Present';
                var isLate = w.todayAttendance && w.todayAttendance.status === 'Late';
                return `
                  <tr style="border-bottom:1px solid var(--border-color);">
                    <td style="padding:10px;">
                      <strong>${w.name}</strong>
                      <div style="font-size:11px; color:var(--text-muted); font-family:monospace;">${w.id} | ${w.phone}</div>
                    </td>
                    <td style="padding:10px;">
                      <span class="badge badge-navy">${w.role}</span>
                      <div style="font-size:11px; color:var(--text-secondary); margin-top:2px;">${w.kitchenId}</div>
                    </td>
                    <td style="padding:10px; font-size:12px;">${w.shift}</td>
                    <td style="padding:10px;">
                      <span class="badge ${isPresent ? 'badge-green' : (isLate ? 'badge-amber' : 'badge-red')}">
                        ${w.todayAttendance ? w.todayAttendance.status : 'Pending'}
                      </span>
                      ${isPresent ? `<div style="font-size:11px; color:#166534;">${w.todayAttendance.checkInTime} (${w.todayAttendance.geofenceDistanceMeters}m GPS)</div>` : ''}
                    </td>
                    <td style="padding:10px;">
                      <span style="font-size:12px; color:${w.medicalStatus.includes('Expiring') ? '#D97706' : (w.medicalStatus.includes('Expired') ? '#DC2626' : '#16A34A')}; font-weight:600;">
                        ${w.medicalStatus}
                      </span>
                    </td>
                    <td style="padding:10px; font-size:12px;">${w.trainingCert}</td>
                    <td style="padding:10px; text-align:center;">
                      <button class="btn btn-outline" style="padding:3px 8px; font-size:11px;" onclick="AkshayaAdminView.viewWorkerTimeline('${w.id}')">
                        Timeline
                      </button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  renderReportsTab: function() {
    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">📑 Official Operations & CSR Donor Report Center</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Generate and download certified reports for Government Mid-Day Meal Authorities, CSR Partners, and Internal Audit.
            </p>
          </div>
          <div style="display:flex; gap:10px;">
            <button class="btn btn-outline" onclick="AkshayaAdminView.exportCSV()">
              📥 Export Excel (.csv)
            </button>
            <button class="btn btn-primary" onclick="AkshayaAdminView.exportPDF()">
              🖨️ Export Official PDF Report
            </button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:18px;">
          <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px;">
            <h4 style="font-size:15px; color:var(--accent-navy); margin-bottom:8px;">📄 Daily Nutritional Operations Summary</h4>
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;">
              Date-wise breakdown of student counts, grain/dal/vegetable weights, delivery temperatures, and shortage incident logs.
            </p>
            <button class="btn btn-secondary" style="font-size:12px; padding:6px 12px;" onclick="AkshayaAdminView.exportDailySummary()">
              Generate Daily PDF
            </button>
          </div>

          <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px;">
            <h4 style="font-size:15px; color:var(--accent-navy); margin-bottom:8px;">🧼 FSSAI Food Hygiene & Water Safety Audit</h4>
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;">
              Comprehensive 0-100 score matrix, RO water microbiology test logs, pest control certificates, and corrective action tracker.
            </p>
            <button class="btn btn-secondary" style="font-size:12px; padding:6px 12px;" onclick="AkshayaAdminView.exportHygieneReport()">
              Generate Hygiene PDF
            </button>
          </div>

          <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px;">
            <h4 style="font-size:15px; color:var(--accent-navy); margin-bottom:8px;">🤝 CSR & Donor Impact Briefing</h4>
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;">
              Philanthropic impact summary: 14.8M meals served, child attendance retention, cost per meal (₹12.80), and sustainable steam boiler energy.
            </p>
            <button class="btn btn-secondary" style="font-size:12px; padding:6px 12px;" onclick="AkshayaAdminView.exportCSRBrief()">
              Download CSR Deck
            </button>
          </div>
        </div>
      </div>
    `;
  },

  showKitchenDetails: function(kId) {
    var k = window.AkshayaData.kitchens.find(item => item.id === kId);
    if (!k) return;
    window.AkshayaNotify.alertModal(
      `🏭 ${k.name} (${k.code})`,
      `Location: ${k.area}\nState: ${k.state} (${k.district})\nDaily Capacity: ${k.dailyCapacity.toLocaleString()} meals\nFed Today: ${k.currentFedToday.toLocaleString()} children\nHygiene Rating: ${k.hygieneRating} (Score: ${k.hygieneScore}/100)\nSupervisor: ${k.supervisor} (${k.supervisorPhone})\nGeofence Radius: ${k.geofenceRadius} meters\nLive Boiler Temp: ${k.boilerTemp}`
    );
  },

  showSchoolDetails: function(sId) {
    var s = window.AkshayaData.schools.find(item => item.id === sId);
    if (!s) return;
    window.AkshayaNotify.alertModal(
      `🏫 ${s.name}`,
      `Route: ${s.route}\nIn-Charge: ${s.contactPerson} (${s.phone})\nEnrolled: ${s.enrolled} Students\nDelivered Today: ${s.todayReceived} meals (${s.todayStatus})\nArrival Time: ${s.receivedTime}\nFood Rating: ${s.rating ? s.rating + ' / 5 Stars' : 'En Route'}`
    );
  },

  refreshMapPins: function() {
    window.AkshayaNotify.toast("Refreshed live GPS telemetry from all 5 delivery vans and 3 kitchens!", "success");
  },

  viewWorkerTimeline: function(wId) {
    var w = window.AkshayaData.workers.find(item => item.id === wId);
    window.AkshayaNotify.alertModal(
      `👤 Activity Timeline: ${w.name}`,
      `Employee ID: ${w.id}\nRole: ${w.role}\nShift: ${w.shift}\nJoining Date: ${w.joiningDate}\nID Proof: ${w.idProof}\nMedical Certificate: ${w.medicalStatus}\nTraining: ${w.trainingCert}\nEmergency Contact: ${w.emergencyContact}\nToday Status: ${w.todayAttendance ? w.todayAttendance.status + ' (' + w.todayAttendance.checkInTime + ')' : 'Pending'}`
    );
  },

  showAddWorkerModal: function() {
    window.AkshayaNotify.alertModal(
      "➕ Register New Employee",
      `New staff onboarding portal:\n- Aadhaar ID Verification\n- Mandatory Medical Fitness Doctor Checkup\n- FoSTaC Food Safety Certification\n- Biometric & GPS registration\n\n[Record will be saved to Master Directory]`
    );
  },

  exportCSV: function() {
    var data = [
      ["Date", "Kitchen", "School", "Enrolled", "Fed", "Shortage_kg", "Shortage_pct", "Temp_Dispatch", "Temp_Arrival", "Status"],
      ["2026-10-29", "BLR-01", "Malleshwaram Primary", "420", "412", "0", "0.0%", "82.4C", "74.0C", "Approved"],
      ["2026-10-29", "BLR-01", "Dr BR Ambedkar Model", "580", "565", "0", "0.0%", "82.4C", "71.2C", "Approved"],
      ["2026-10-29", "HBL-02", "Gokul High School", "460", "450", "0", "0.0%", "81.0C", "72.0C", "Approved"],
      ["2026-10-29", "MYS-03", "Maharaja High School", "620", "590", "15", "1.66%", "78.0C", "68.0C", "Shortage Flagged"]
    ];

    var csvContent = "data:text/csv;charset=utf-8," + data.map(e => e.join(",")).join("\n");
    var encodedUri = encodeURI(csvContent);
    var link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Akshaya_Seva_Daily_Operations_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.AkshayaNotify.toast("Excel CSV export generated & downloaded successfully!", "success");
  },

  exportPDF: function() {
    window.print();
  },

  exportDailySummary: function() {
    window.print();
  },

  exportHygieneReport: function() {
    window.print();
  },

  exportCSRBrief: function() {
    window.AkshayaNotify.alertModal(
      "🤝 CSR Donor Impact Briefing",
      `Akshaya Seva Foundation - Mid-Day Meal Impact:\n• 14.82 Million Meals Delivered YTD\n• 100% Thermal Retained Insulated Vans\n• ₹12.80 Cost Per Wholesome Meal\n• 4 Key Donors: Infosys Foundation, Tata Trusts, Azim Premji Philanthropies, L&T Care\n\n[Report compiled for board presentation]`
    );
  }
};
