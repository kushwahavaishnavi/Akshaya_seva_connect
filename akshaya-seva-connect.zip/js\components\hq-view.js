// Headquarters (HQ Role): National Analytics, Reports Inbox & Approval Workflow
window.AkshayaHQView = {
  activeHQTab: 'inbox', // 'inbox', 'analytics', 'rankings', 'csr'

  render: function() {
    var inbox = window.AkshayaData.hqInbox;
    var kitchens = window.AkshayaData.kitchens;

    return `
      <div class="single-panel-layout" style="border-top: 4px solid var(--accent-navy);">
        <!-- HQ Header -->
        <div class="card" style="background: linear-gradient(135deg, #1B2A41 0%, #2A4365 100%); color:#FFFFFF;">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:rgba(255,255,255,0.15); border:1px solid rgba(255,255,255,0.3); color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                🏛️
              </div>
              <div>
                <h2 style="font-size:22px; color:#FFFFFF; margin-bottom:2px;">Akshaya Seva Headquarters Command</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:#CBD5E1;">
                  <span class="badge" style="background:rgba(255,255,255,0.2); color:#FFF;">HQ Operations Director</span>
                  <span>📍 Central Mission Directorate, Bengaluru</span>
                  <span class="badge" style="background:#22C55E; color:#FFF;">Live Sync Active</span>
                </div>
              </div>
            </div>

            <div style="text-align:right;">
              <div style="font-size:26px; font-weight:700; color:#38BDF8;">54,100</div>
              <div style="font-size:12px; color:#94A3B8;">Statewide Children Fed Today</div>
            </div>
          </div>
        </div>

        <!-- HQ Navigation Tabs -->
        <div style="display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
          <button class="btn ${this.activeHQTab === 'inbox' ? 'btn-secondary' : 'btn-outline'}" onclick="AkshayaHQView.setTab('inbox')">
            📥 Submitted Reports Inbox (${inbox.length})
          </button>
          <button class="btn ${this.activeHQTab === 'rankings' ? 'btn-secondary' : 'btn-outline'}" onclick="AkshayaHQView.setTab('rankings')">
            🏆 Kitchen Rankings & Audits
          </button>
          <button class="btn ${this.activeHQTab === 'csr' ? 'btn-secondary' : 'btn-outline'}" onclick="AkshayaHQView.setTab('csr')">
            🤝 CSR & Donor Transparency
          </button>
        </div>

        <!-- Tab Body -->
        ${this.activeHQTab === 'inbox' ? this.renderInboxTab(inbox) : ''}
        ${this.activeHQTab === 'rankings' ? this.renderRankingsTab(kitchens) : ''}
        ${this.activeHQTab === 'csr' ? this.renderCSRTab() : ''}
      </div>
    `;
  },

  setTab: function(tab) {
    this.activeHQTab = tab;
    if (window.renderApp) window.renderApp();
  },

  renderInboxTab: function(inbox) {
    return `
      <div style="display:flex; flex-direction:column; gap:16px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <h3 style="font-size:16px; color:var(--accent-navy); font-weight:600;">
            Daily Field Operations Reports Received from Admin
          </h3>
          <span style="font-size:12px; color:var(--text-secondary);">
            Synchronized with Admin via WebSockets / Broadcast Engine
          </span>
        </div>

        ${inbox.map(item => `
          <div class="card ${item.isNew ? 'highlight-incoming' : ''}" style="border-left: 4px solid ${item.status === 'Acknowledged' ? 'var(--accent-green)' : 'var(--accent-navy)'};">
            <div class="card-header">
              <div>
                <div style="display:flex; align-items:center; gap:8px;">
                  <h3 class="card-title">${item.kitchenName}</h3>
                  ${item.isNew ? '<span class="badge badge-saffron" style="animation:pulse-sos 1.5s infinite;">NEW ARRIVAL</span>' : ''}
                </div>
                <div style="font-size:12px; color:var(--text-secondary); margin-top:3px;">
                  Report: <strong>${item.reportId}</strong> | Submitted by: ${item.submittedBy} (${new Date(item.submittedAt).toLocaleTimeString()})
                </div>
              </div>

              <div style="display:flex; gap:8px; align-items:center;">
                <span class="badge ${item.status === 'Acknowledged' ? 'badge-green' : 'badge-amber'}">
                  ${item.status}
                </span>
              </div>
            </div>

            <!-- Key Indicators Grid -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px; background:#F8FAFC; padding:12px; border-radius:var(--radius-sm); margin-bottom:14px; font-size:13px;">
              <div><strong>Children Fed:</strong> ${item.totalFed.toLocaleString()}</div>
              <div><strong>On-Time Rate:</strong> ${item.onTimeDeliveryRate}</div>
              <div><strong>Shortage Rate:</strong> ${item.shortageRate}</div>
              <div><strong>Hygiene Score:</strong> ${item.hygieneScore} / 100</div>
            </div>

            ${item.hqComments ? `
              <div style="padding:10px 14px; background:#F0FDF4; border-radius:var(--radius-sm); border:1px solid #BBF7D0; font-size:13px; color:#166534; margin-bottom:14px;">
                ✓ <strong>HQ Remark (${item.acknowledgedBy || 'Director'}):</strong> ${item.hqComments}
              </div>
            ` : ''}

            <!-- HQ Action Buttons -->
            <div style="display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap;">
              <button class="btn btn-outline" style="border-color:var(--status-amber); color:var(--status-amber); font-size:13px; padding:6px 14px;" onclick="AkshayaHQView.requestClarification('${item.id}')">
                ❓ Request Clarification
              </button>
              <button class="btn btn-secondary" style="font-size:13px; padding:6px 14px;" onclick="AkshayaHQView.addCommentModal('${item.id}')">
                💬 Add HQ Remark
              </button>
              ${item.status !== 'Acknowledged' ? `
                <button class="btn btn-success" style="font-size:13px; padding:6px 14px;" onclick="AkshayaHQView.acknowledgeReport('${item.id}')">
                  ✅ Acknowledge & Archive
                </button>
              ` : `
                <span style="font-size:12px; color:var(--accent-green); display:flex; align-items:center; gap:6px;">
                  ✓ Formally Acknowledged by HQ
                </span>
              `}
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  renderRankingsTab: function(kitchens) {
    var sorted = kitchens.slice().sort((a, b) => b.hygieneScore - a.hygieneScore);

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">🏆 Statewide Kitchen Performance & Hygiene Benchmarking</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Ranking based on FSSAI audits, on-time delivery rate, zero shortages, and clean employee attendance.
            </p>
          </div>
          <span class="badge badge-navy">Q3 Assessment</span>
        </div>

        <div style="display:flex; flex-direction:column; gap:14px;">
          ${sorted.map((k, idx) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:16px; background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); border-left:5px solid ${idx === 0 ? '#16A34A' : (idx === 1 ? '#0284C7' : '#D97706')}; flex-wrap:wrap; gap:12px;">
              <div style="display:flex; align-items:center; gap:14px;">
                <div style="width:36px; height:36px; border-radius:50%; background:${idx === 0 ? '#FEF08A' : '#E2E8F0'}; color:#1B2A41; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:16px;">
                  #${idx + 1}
                </div>
                <div>
                  <h4 style="font-size:16px; color:var(--accent-navy);">${k.name}</h4>
                  <div style="font-size:12px; color:var(--text-secondary);">
                    Supervisor: ${k.supervisor} | Capacity: ${k.dailyCapacity.toLocaleString()} meals/day
                  </div>
                </div>
              </div>

              <div style="display:flex; align-items:center; gap:20px;">
                <div style="text-align:right;">
                  <div style="font-size:22px; font-weight:700; color:${k.hygieneRating === 'Green' ? '#16A34A' : '#D97706'};">
                    ${k.hygieneScore}%
                  </div>
                  <div style="font-size:11px; color:var(--text-secondary); text-transform:uppercase; font-weight:600;">
                    ${k.hygieneRating} Rating
                  </div>
                </div>
                <button class="btn btn-outline" style="font-size:12px; padding:6px 12px;" onclick="AkshayaAdminView.showKitchenDetails('${k.id}')">
                  Full Audit History
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  renderCSRTab: function() {
    var csr = window.AkshayaData.csrSummary;

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">🤝 CSR & Institutional Donor Summary</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Transparent governance metrics for corporate partners, foundation trustees, and donors.
            </p>
          </div>
          <button class="btn btn-primary" onclick="AkshayaAdminView.exportPDF()">
            🖨️ Print CSR Summary
          </button>
        </div>

        <div class="kpi-grid" style="margin-bottom:20px;">
          <div class="kpi-card" style="border-left:4px solid #0284C7;">
            <div class="kpi-title">YTD Meals Served</div>
            <div class="kpi-val">${csr.totalMealsServedYTD}</div>
            <div class="kpi-sub positive">Zero Nutritional Compromise</div>
          </div>

          <div class="kpi-card" style="border-left:4px solid #16A34A;">
            <div class="kpi-title">Cost Efficiency Per Meal</div>
            <div class="kpi-val">${csr.costPerMeal}</div>
            <div class="kpi-sub positive">Automated Mega-Scale Kitchens</div>
          </div>

          <div class="kpi-card" style="border-left:4px solid #F59E0B;">
            <div class="kpi-title">Nutritional Index</div>
            <div class="kpi-val">${csr.childrenNutritionalIndex}</div>
            <div class="kpi-sub positive">Quarterly Health Screening</div>
          </div>
        </div>

        <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px;">
          <h4 style="font-size:15px; color:var(--accent-navy); margin-bottom:8px;">🏛️ Corporate Donors & CSR Benefactors</h4>
          <div style="display:flex; gap:12px; flex-wrap:wrap;">
            ${csr.partnerCorporates.map(p => `
              <span class="badge badge-navy" style="font-size:13px; padding:6px 14px;">${p}</span>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  },

  acknowledgeReport: function(inboxId) {
    var item = window.AkshayaData.hqInbox.find(i => i.id === inboxId);
    if (!item) return;

    item.status = 'Acknowledged';
    item.isNew = false;
    item.acknowledgedBy = 'Dr. Pratibha Murthy (HQ Director)';
    item.acknowledgedAt = new Date().toISOString();
    item.hqComments = 'Operations approved. Commendable adherence to hygiene & zero waste.';

    // Broadcast acknowledgment back to Admin panel
    window.AkshayaSync.broadcast('REPORT_ACKNOWLEDGED_HQ', {
      reportId: item.reportId,
      acknowledgedBy: item.acknowledgedBy,
      comment: item.hqComments
    });

    window.AkshayaNotify.toast(`Report #${item.reportId} acknowledged by HQ! Admin notified immediately.`, "success");
    if (window.renderApp) window.renderApp();
  },

  requestClarification: function(inboxId) {
    var item = window.AkshayaData.hqInbox.find(i => i.id === inboxId);
    if (!item) return;
    item.status = 'Clarification Requested';
    item.isNew = false;

    window.AkshayaSync.broadcast('REPORT_CLARIFICATION_HQ', {
      reportId: item.reportId,
      requestedBy: 'HQ Operations Team'
    });

    window.AkshayaNotify.toast(`Clarification requested for #${item.reportId}. Notification dispatched to Admin panel.`, "warning");
    if (window.renderApp) window.renderApp();
  },

  addCommentModal: function(inboxId) {
    var remark = prompt("Enter HQ Operations Directive or Appreciation Remark:", "Compliant with state midday meal quality charter.");
    if (remark) {
      var item = window.AkshayaData.hqInbox.find(i => i.id === inboxId);
      if (item) {
        item.hqComments = remark;
        window.AkshayaSync.broadcast('HQ_COMMENT_ADDED', { reportId: item.reportId, comment: remark });
        window.AkshayaNotify.toast("HQ Remark added & synced!", "success");
        if (window.renderApp) window.renderApp();
      }
    }
  }
};
