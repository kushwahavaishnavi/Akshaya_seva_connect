// Multi-language Dictionaries & Voice Assist System
window.AkshayaI18n = {
  currentLang: 'en',
  
  languages: [
    { code: 'en', name: 'English', native: 'English', voiceLang: 'en-IN' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी', voiceLang: 'hi-IN' },
    { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', voiceLang: 'kn-IN' },
    { code: 'ta', name: 'Tamil', native: 'தமிழ்', voiceLang: 'ta-IN' },
    { code: 'te', name: 'Telugu', native: 'తెలుగు', voiceLang: 'te-IN' },
    { code: 'mr', name: 'Marathi', native: 'मराठी', voiceLang: 'mr-IN' },
    { code: 'bn', name: 'Bengali', native: 'বাংলা', voiceLang: 'bn-IN' }
  ],

  translations: {
    en: {
      appName: "Akshaya Seva Connect",
      appTagline: "Mid-Day Meal Digital Operations & Transparency",
      // Roles
      role_worker: "Kitchen Worker",
      role_driver: "Delivery Driver",
      role_supplier: "Raw Material Supplier",
      role_school: "School Representative",
      role_supervisor: "Kitchen Supervisor",
      role_admin: "Admin / Management",
      role_hq: "Headquarters (HQ)",
      role_public: "Public / Citizen",
      // Navigation
      nav_home: "Overview",
      nav_attendance: "GPS Attendance",
      nav_daily_report: "Daily Report",
      nav_photo_check: "Daily Photos",
      nav_hygiene_audit: "Hygiene Audit",
      nav_complaints: "Complaints & SLA",
      nav_delivery: "Delivery Proof",
      nav_supplier: "Supplies & Stock",
      nav_reports: "CSR & Reports",
      nav_users: "User Directory",
      nav_hq_sync: "HQ Sync Command",
      // Common Actions
      btn_check_in: "Check In (Selfie & GPS)",
      btn_check_out: "Check Out",
      btn_submit_report: "Submit Daily Report",
      btn_raise_complaint: "Raise Complaint",
      btn_track_ticket: "Track Complaint",
      btn_submit_hq: "Submit Final Report to HQ",
      btn_acknowledge: "Acknowledge Report",
      btn_request_clarification: "Request Clarification",
      btn_export_pdf: "Export Official PDF",
      btn_export_excel: "Export Excel Sheet",
      btn_listen_voice: "Voice Assist (Read Aloud)",
      btn_sos: "EMERGENCY SOS",
      // KPIs
      kpi_fed_today: "Children Fed Today",
      kpi_food_delivered: "Food Delivered (kg)",
      kpi_shortage_rate: "Shortage Rate (%)",
      kpi_ontime: "On-Time Dispatch",
      kpi_attendance: "Worker Attendance",
      kpi_hygiene: "Avg Hygiene Score",
      kpi_complaints: "Open Complaints",
      // Status
      status_present: "Present",
      status_late: "Late",
      status_absent: "Absent",
      status_approved: "Approved",
      status_submitted: "Submitted",
      status_draft: "Draft",
      status_critical: "CRITICAL ALERT",
      // Forms
      lbl_kitchen: "Select Kitchen / Hub",
      lbl_school: "Select School / Center",
      lbl_date: "Date of Operations",
      lbl_children_fed: "Number of Children Fed",
      lbl_menu: "Mid-Day Menu Served",
      lbl_shortage_toggle: "Any Food Shortage Observed?",
      lbl_temp_dispatch: "Dispatch Temp (°C)",
      lbl_temp_arrival: "Arrival Temp (°C)",
      lbl_wastage: "Food Wastage / Leftover (kg)",
      lbl_driver: "Driver Name & Vehicle",
      lbl_remarks: "Supervisor Observations",
      // Alerts
      offline_banner: "You are currently OFFLINE. Offline data is cached in IndexedDB and will auto-sync when online.",
      sync_success: "Changes synchronized successfully!",
      geofence_verified: "GPS Geofence Verified! You are within 18m of the designated kitchen.",
      geofence_failed: "Warning: Location outside kitchen geofence boundary! Photo flagged for supervisor audit.",
      critical_banner: "EMERGENCY ALERT: Foreign material report in Sambar at Mysuru School. Operations review triggered!"
    },
    hi: {
      appName: "अक्षय सेवा कनेक्ट",
      appTagline: "मध्याह्न भोजन डिजिटल संचालन एवं पारदर्शिता",
      role_worker: "रसोई कार्यकर्ता",
      role_driver: "डिलीवरी चालक",
      role_supplier: "कच्चा माल आपूर्तिकर्ता",
      role_school: "विद्यालय प्रभारी / शिक्षक",
      role_supervisor: "रसोई पर्यवेक्षक",
      role_admin: "प्रशासन / प्रबंधन",
      role_hq: "मुख्यालय (HQ)",
      role_public: "नागरिक / अभिभावक",
      nav_home: "मुख्य पृष्ठ",
      nav_attendance: "जीपीएस उपस्थिति",
      nav_daily_report: "दैनिक रिपोर्ट",
      nav_photo_check: "दैनिक फोटो जांच",
      nav_hygiene_audit: "स्वच्छता ऑडिट",
      nav_complaints: "शिकायत एवं निवारण",
      nav_delivery: "डिलीवरी रसीद",
      nav_supplier: "सामग्री एवं स्टॉक",
      nav_reports: "रिपोर्ट केंद्र",
      nav_users: "कर्मचारी सूची",
      nav_hq_sync: "मुख्यालय समन्वय",
      btn_check_in: "उपस्थिति दर्ज करें (सेल्फी + जीपीएस)",
      btn_check_out: "चेक आउट",
      btn_submit_report: "दैनिक रिपोर्ट जमा करें",
      btn_raise_complaint: "शिकायत दर्ज करें",
      btn_track_ticket: "शिकायत की स्थिति जांचें",
      btn_submit_hq: "मुख्यालय को रिपोर्ट भेजें",
      btn_acknowledge: "स्वीकृति दें",
      btn_request_clarification: "स्पष्टीकरण मांगें",
      btn_export_pdf: "पीडीएफ निर्यात",
      btn_export_excel: "एक्सेल निर्यात",
      btn_listen_voice: "आवाज में सुनें (वॉयस)",
      btn_sos: "आपातकालीन एसओएस",
      kpi_fed_today: "आज भोजन प्राप्त बच्चे",
      kpi_food_delivered: "वितरित भोजन (किग्रा)",
      kpi_shortage_rate: "कमी की दर (%)",
      kpi_ontime: "समय पर डिलीवरी",
      kpi_attendance: "कर्मचारी उपस्थिति",
      kpi_hygiene: "स्वच्छता स्कोर",
      kpi_complaints: "सक्रिय शिकायतें",
      status_present: "उपस्थित",
      status_late: "विलंब",
      status_absent: "अनुपस्थित",
      status_approved: "स्वीकृत",
      status_submitted: "प्रस्तुत",
      status_draft: "ड्राफ्ट",
      status_critical: "आपातकालीन चेतावनी",
      lbl_kitchen: "रसोई / केंद्र चुनें",
      lbl_school: "विद्यालय चुनें",
      lbl_date: "संचालन तिथि",
      lbl_children_fed: "भोजन प्राप्त बच्चों की संख्या",
      lbl_menu: "परोसा गया भोजन",
      lbl_shortage_toggle: "क्या कोई कमी पाई गई?",
      lbl_temp_dispatch: "रवाना तापमान (°C)",
      lbl_temp_arrival: "पहुंच तापमान (°C)",
      lbl_wastage: "बचा हुआ या व्यर्थ भोजन (किग्रा)",
      lbl_driver: "चालक एवं वाहन संख्या",
      lbl_remarks: "पर्यवेक्षक टिप्पणी",
      offline_banner: "आप ऑफलाइन हैं। डेटा सुरक्षित रूप से संग्रहीत है और ऑनलाइन होने पर स्वतः सिंक होगा।",
      sync_success: "डेटा सफलतापूर्वक सिंक हुआ!",
      geofence_verified: "जीपीएस सत्यापित! आप स्वीकृत रसोई परिसर में उपस्थित हैं।",
      geofence_failed: "चेतावनी: आप रसोई परिसर से बाहर हैं! फोटो पर्यवेक्षक को भेजी गई।",
      critical_banner: "आपातकालीन चेतावनी: मैसूर स्कूल में सांभर में बाहरी वस्तु की सूचना। जांच जारी!"
    },
    kn: {
      appName: "ಅಕ್ಷಯ ಸೇವಾ ಕನೆಕ್ಟ್",
      appTagline: "ಮಧ್ಯಾಹ್ನದ ಬಿಸಿಯೂಟ ಡಿಜಿಟಲ್ ಕಾರ್ಯಾಚರಣೆ ಮತ್ತು ಪಾರದರ್ಶಕತೆ",
      role_worker: "ಅಡುಗೆ ಸಿಬ್ಬಂದಿ",
      role_driver: "ವಾಹನ ಚಾಲಕ",
      role_supplier: "ದವಸ-ಧಾನ್ಯ ಸರಬರಾಜುದಾರ",
      role_school: "ಶಾಲಾ ಪ್ರತಿನಿಧಿ / ಶಿಕ್ಷಕರು",
      role_supervisor: "ಅಡುಗೆ ಮನೆ ಮೇಲ್ವಿಚಾರಕ",
      role_admin: "ಆಡಳಿತ ಮಂಡಳಿ",
      role_hq: "ಕೇಂದ್ರ ಕಚೇರಿ (HQ)",
      role_public: "ಸಾರ್ವಜನಿಕರು / ಪೋಷಕರು",
      nav_home: "ಮುಖಪುಟ",
      nav_attendance: "ಜಿಪಿಎಸ್ ಹಾಜರಾತಿ",
      nav_daily_report: "ದೈನಂದಿನ ವರದಿ",
      nav_photo_check: "ದೈನಂದಿನ ಫೋಟೋ ಪರಿಶೀಲನೆ",
      nav_hygiene_audit: "ನೈರ್ಮಲ್ಯ ಆಡಿಟ್",
      nav_complaints: "ದೂರು & ಪರಿಹಾರ",
      nav_delivery: "ವಿತರಣಾ ದೃಢೀಕರಣ",
      nav_supplier: "ದಾಸ್ತಾನು & ಸರಬರಾಜು",
      nav_reports: "ವರದಿ ಕೇಂದ್ರ",
      nav_users: "ಸಿಬ್ಬಂದಿ ವಿವರ",
      nav_hq_sync: "ಕೇಂದ್ರ ಕಚೇರಿ ಸಮನ್ವಯ",
      btn_check_in: "ಹಾಜರಾತಿ ನಮೂದಿಸಿ (ಸೆಲ್ಫಿ + ಜಿಪಿಎಸ್)",
      btn_check_out: "ಚೆಕ್ ಔಟ್",
      btn_submit_report: "ದೈನಂದಿನ ವರದಿ ಸಲ್ಲಿಸಿ",
      btn_raise_complaint: "ದೂರು ದಾಖಲಿಸಿ",
      btn_track_ticket: "ದೂರಿನ ಸ್ಥಿತಿ ತಿಳಿಯಿರಿ",
      btn_submit_hq: "ಕೇಂದ್ರ ಕಚೇರಿಗೆ ವರದಿ ಕಳುಹಿಸಿ",
      btn_acknowledge: "ಸ್ವೀಕರಿಸಲಾಗಿದೆ",
      btn_request_clarification: "ವಿವರಣೆ ಕೇಳಿ",
      btn_export_pdf: "ಪಿಡಿಎಫ್ ಡೌನ್‌ಲೋಡ್",
      btn_export_excel: "ಎಕ್ಸೆಲ್ ಡೌನ್‌ಲೋಡ್",
      btn_listen_voice: "ಧ್ವನಿ ಸಹಾಯ (ಕೇಳಿ)",
      btn_sos: "ತುರ್ತು ಎಸ್‌ಒಎಸ್ (SOS)",
      kpi_fed_today: "ಊಟ ಸವಿದ ಮಕ್ಕಳು",
      kpi_food_delivered: "ವಿತರಿಸಲಾದ ಊಟ (ಕೆ.ಜಿ)",
      kpi_shortage_rate: "ಕೊರತೆ ಪ್ರಮಾಣ (%)",
      kpi_ontime: "ಸಮಯಕ್ಕೆ ಸರಿಯಾಗಿ ವಿತರಣೆ",
      kpi_attendance: "ಸಿಬ್ಬಂದಿ ಹಾಜರಾತಿ",
      kpi_hygiene: "ನೈರ್ಮಲ್ಯ ಅಂಕ",
      kpi_complaints: "ಬಾಕಿ ದೂರುಗಳು",
      status_present: "ಹಾಜರು",
      status_late: "ತಡವಾಗಿ ಬಂದವರು",
      status_absent: "ಗೈರುಹಾಜರು",
      status_approved: "ಅನುಮೋದಿಸಲಾಗಿದೆ",
      status_submitted: "ಸಲ್ಲಿಸಲಾಗಿದೆ",
      status_draft: "ಕರಡು",
      status_critical: "ತುರ್ತು ಎಚ್ಚರಿಕೆ",
      lbl_kitchen: "ಅಡುಗೆ ಮನೆ ಆಯ್ಕೆ ಮಾಡಿ",
      lbl_school: "ಶಾಲೆ ಆಯ್ಕೆ ಮಾಡಿ",
      lbl_date: "ದಿನಾಂಕ",
      lbl_children_fed: "ಊಟ ಪಡೆದ ಮಕ್ಕಳ ಸಂಖ್ಯೆ",
      lbl_menu: "ಇಂದಿನ ಮೆನು",
      lbl_shortage_toggle: "ಊಟದ ಕೊರತೆ ಕಂಡುಬಂದಿದೆಯೇ?",
      lbl_temp_dispatch: "ಹೊರಡುವಾಗ ತಾಪಮಾನ (°C)",
      lbl_temp_arrival: "ತಲುಪಿದಾಗ ತಾಪಮಾನ (°C)",
      lbl_wastage: "ವ್ಯರ್ಥವಾದ ಆಹಾರ (ಕೆ.ಜಿ)",
      lbl_driver: "ಚಾಲಕ ಮತ್ತು ವಾಹನ ಸಂಖ್ಯೆ",
      lbl_remarks: "ಮೇಲ್ವಿಚಾರಕರ ಅಭಿಪ್ರಾಯ",
      offline_banner: "ನೀವು ಆಫ್‌ಲೈನ್‌ನಲ್ಲಿದ್ದೀರಿ. ಡೇಟಾವನ್ನು ಸುರಕ್ಷಿತವಾಗಿಡಲಾಗಿದೆ ಮತ್ತು ನೆಟ್‌ವರ್ಕ್ ಬಂದಾಗ ತಾನಾಗಿಯೇ ಅಪ್‌ಡೇಟ್ ಆಗುತ್ತದೆ.",
      sync_success: "ಡೇಟಾ ಯಶಸ್ವಿಯಾಗಿ ಸಿಂಕ್ ಆಗಿದೆ!",
      geofence_verified: "ಜಿಪಿಎಸ್ ದೃಢೀಕರಿಸಲಾಗಿದೆ! ನೀವು ಅಡುಗೆ ಮನೆಯಲ್ಲಿದ್ದೀರಿ.",
      geofence_failed: "ಎಚ್ಚರಿಕೆ: ನೀವು ಅಡುಗೆ ಮನೆಯ ಪರಿಧಿಯ ಹೊರಗಿದ್ದೀರಿ! ಮೇಲ್ವಿಚಾರಕರ ಪರಿಶೀಲನೆಗೆ ಕಳುಹಿಸಲಾಗಿದೆ.",
      critical_banner: "ತುರ್ತು ಎಚ್ಚರಿಕೆ: ಮೈಸೂರು ಶಾಲೆಯಲ್ಲಿ ಸಾಂಬಾರಿನಲ್ಲಿ ಅಪರಿಚಿತ ವಸ್ತು ವರದಿ! ಪರಿಶೀಲನೆ ಆರಂಭಿಸಲಾಗಿದೆ."
    },
    ta: {
      appName: "அக்ஷய சேவா கனெக்ட்",
      appTagline: "மதிய உணவு டிஜிட்டல் செயல்பாடுகள் மற்றும் வெளிப்படைத்தன்மை",
      role_worker: "சமையலறை ஊழியர்",
      role_driver: "டெலிவரி ஓட்டுநர்",
      role_supplier: "பொருட்கள் வழங்குநர்",
      role_school: "பள்ளி ஆசிரியர்",
      role_supervisor: "சமையலறை மேற்பார்வையாளர்",
      role_admin: "நிர்வாகம்",
      role_hq: "தலைமையகம் (HQ)",
      role_public: "பொதுமக்கள் / பெற்றோர்",
      btn_check_in: "வருகை பதிவு (செல்ஃபி + ஜி.பி.எஸ்)",
      btn_submit_report: "அறிக்கை சமர்ப்பிக்கவும்",
      btn_raise_complaint: "புகார் அளிக்கவும்",
      kpi_fed_today: "உணவு உண்ட குழந்தைகள்",
      kpi_food_delivered: "வழங்கப்பட்ட உணவு (கிலோ)",
      status_present: "வருகை",
      status_approved: "அங்கீகரிக்கப்பட்டது"
    },
    te: {
      appName: "అక్షయ సేవా కనెక్ట్",
      appTagline: "మధ్యాహ్న భోజన డిజిటల్ కార్యకలాపాలు",
      role_worker: "వంటశాల సిబ్బంది",
      role_driver: "డెలివరీ డ్రైవర్",
      role_supplier: "సరఫరాదారు",
      role_school: "పాఠశాల ప్రతినిధి",
      role_supervisor: "సూపర్‌వైజర్",
      role_admin: "అడ్మిన్",
      role_hq: "ప్రధాన కార్యాలయం",
      btn_check_in: "హాజరు నమోదు (సెల్ఫీ + జీపీఎస్)",
      btn_submit_report: "నివేదిక సమర్పించండి",
      btn_raise_complaint: "ఫిర్యాదు చేయండి",
      kpi_fed_today: "భోజనం చేసిన పిల్లలు",
      kpi_food_delivered: "పంపిణీ ఆహారం (కిలోలు)",
      status_present: "హాజరు",
      status_approved: "ఆమోదించబడింది"
    },
    mr: {
      appName: "अक्षय सेवा कनेक्ट",
      appTagline: "मध्यान्ह भोजन डिजिटल कार्यप्रणाली",
      role_worker: "स्वयंपाकघर कर्मचारी",
      role_driver: "वाहन चालक",
      role_supplier: "पुरवठादार",
      role_school: "शाळा प्रतिनिधी",
      role_supervisor: "पर्यवेक्षक",
      role_admin: "प्रशासन",
      role_hq: "मुख्यालय",
      btn_check_in: "हजेरी नोंदवा (सेल्फी + जीपीएस)",
      btn_submit_report: "दैनिक अहवाल सादर करा",
      btn_raise_complaint: "तक्रार नोंदवा",
      kpi_fed_today: "जेवण घेतलेली मुले",
      kpi_food_delivered: "अन्न वितरण (किलो)",
      status_present: "उपस्थित",
      status_approved: "मंजूर"
    },
    bn: {
      appName: "অক্ষয় সেবা কানেক্ট",
      appTagline: "মিড-ডে মিল ডিজিটাল অপারেশন ও স্বচ্ছতা",
      role_worker: "রান্নাঘর কর্মী",
      role_driver: "ডেলিভারি চালক",
      role_supplier: "সরবরাহকারী",
      role_school: "স্কুল প্রতিনিধি",
      role_supervisor: "তত্ত্বাবধায়ক",
      role_admin: "প্রশাসন",
      role_hq: "সদর দপ্তর",
      btn_check_in: "উপস্থিতি দিন (সেলফি + জিপিএস)",
      btn_submit_report: "দৈনিক রিপোর্ট জমা দিন",
      btn_raise_complaint: "অভিযোগ জানান",
      kpi_fed_today: "আহার গ্রহণকারী শিশু",
      kpi_food_delivered: "বিতরণকৃত খাদ্য (কেজি)",
      status_present: "উপস্থিত",
      status_approved: "অনুমোদিত"
    }
  },

  t: function(key) {
    var lang = this.currentLang;
    if (this.translations[lang] && this.translations[lang][key]) {
      return this.translations[lang][key];
    }
    if (this.translations['en'] && this.translations['en'][key]) {
      return this.translations['en'][key];
    }
    return key;
  },

  setLanguage: function(langCode) {
    if (this.translations[langCode]) {
      this.currentLang = langCode;
      localStorage.setItem('akshaya_lang', langCode);
      document.documentElement.lang = langCode;
      if (window.renderApp) {
        window.renderApp();
      }
    }
  },

  speakText: function(text) {
    if (!('speechSynthesis' in window)) {
      alert("Speech synthesis is not supported on this device/browser.");
      return;
    }
    window.speechSynthesis.cancel();
    var utterance = new SpeechSynthesisUtterance(text);
    var langObj = this.languages.find(l => l.code === this.currentLang) || this.languages[0];
    utterance.lang = langObj.voiceLang || 'en-IN';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  }
};

// Initialize language from storage
(function() {
  var saved = localStorage.getItem('akshaya_lang');
  if (saved && window.AkshayaI18n.translations[saved]) {
    window.AkshayaI18n.currentLang = saved;
  }
})();
