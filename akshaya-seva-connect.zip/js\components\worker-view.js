// Worker Interface: Attendance (Camera + GPS), 7-Point Photo Check & Leave
window.AkshayaWorkerView = {
  activeTab: 'attendance',
  cameraStream: null,
  capturedSelfieData: null,

  render: function() {
    var workers = window.AkshayaData.workers;
    var currentWorker = workers[0]; // Basavaraju M. (Head Cook)
    var kitchen = window.AkshayaData.kitchens.find(k => k.id === currentWorker.kitchenId);
    var t = window.AkshayaI18n.t.bind(window.AkshayaI18n);

    return `
      <div class="single-panel-layout">
        <!-- Worker Profile Header Card -->
        <div class="card" style="background: linear-gradient(135deg, #FFF9F2 0%, #FFFFFF 100%); border-left: 5px solid var(--primary-saffron);">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:50%; background:#F28C28; color:#FFF; display:flex; align-items:center; justify-content:center; font-size:28px; font-weight:700; border:3px solid #FFF; box-shadow:var(--shadow-sm);">
                👨‍🍳
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">${currentWorker.name}</h2>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span class="badge badge-saffron">${currentWorker.role}</span>
                  <span>📍 ${kitchen ? kitchen.name : 'Central Kitchen'}</span>
                  <span>⏰ ${currentWorker.shift}</span>
                </div>
              </div>
            </div>

            <div style="display:flex; gap:10px;">
              <button class="btn btn-outline" onclick="AkshayaWorkerView.showLeaveModal()">
                📅 Request Leave
              </button>
              <button class="btn btn-primary" onclick="AkshayaWorkerView.setTab('attendance')">
                📸 Today's Check-in
              </button>
            </div>
          </div>
        </div>

        <!-- Sub Navigation Tabs -->
        <div style="display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
          <button class="btn ${this.activeTab === 'attendance' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaWorkerView.setTab('attendance')">
            📍 GPS Attendance & Selfie
          </button>
          <button class="btn ${this.activeTab === 'photos' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaWorkerView.setTab('photos')">
            📸 7-Point Daily Photo Check
          </button>
          <button class="btn ${this.activeTab === 'calendar' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaWorkerView.setTab('calendar')">
            🗓️ Monthly Calendar & Logs
          </button>
        </div>

        <!-- Tab Body -->
        ${this.activeTab === 'attendance' ? this.renderAttendanceTab(currentWorker, kitchen) : ''}
        ${this.activeTab === 'photos' ? this.renderPhotoCheckTab(kitchen) : ''}
        ${this.activeTab === 'calendar' ? this.renderCalendarTab(currentWorker) : ''}
      </div>
    `;
  },

  setTab: function(tabName) {
    this.activeTab = tabName;
    if (tabName !== 'attendance' && this.cameraStream) {
      this.stopCamera();
    }
    if (window.renderApp) window.renderApp();
  },

  renderAttendanceTab: function(worker, kitchen) {
    var att = worker.todayAttendance;
    var isPresent = att && att.status === 'Present';

    return `
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
        <!-- Left Column: Camera Check-In Interface -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📸 Live Camera Check-in & GPS Stamp</h3>
            <span class="badge ${isPresent ? 'badge-green' : 'badge-amber'}">
              ${isPresent ? 'Checked In (' + att.checkInTime + ')' : 'Pending Check-In'}
            </span>
          </div>

          <div style="margin-bottom:16px;">
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;">
              Anti-fraud enabled: Requires live browser camera selfie with verified GPS geofencing (< ${kitchen.geofenceRadius}m radius). Photo gallery upload is blocked.
            </p>

            <div class="camera-container" id="camera-box">
              <video id="webcam-preview" autoplay playsinline style="width:100%; height:100%; object-fit:cover; display:none;"></video>
              <canvas id="selfie-canvas" style="width:100%; height:100%; object-fit:cover; display:none;"></canvas>
              <div id="camera-placeholder" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; color:#AAA; padding:20px; text-align:center;">
                <span style="font-size:48px; margin-bottom:8px;">📷</span>
                <p style="color:#FFF; font-weight:600; font-size:14px;">Browser Camera Ready</p>
                <p style="color:#CCC; font-size:12px; margin-top:4px;">Click 'Start Camera' to open live selfie stream</p>
              </div>

              <!-- Watermark Overlay Preview -->
              <div class="watermark-overlay" id="watermark-box" style="display:none;">
                <div>AKSHAYA SEVA FOUNDATION - DIGITAL ATTENDANCE</div>
                <div id="wm-meta">EMP: ${worker.name} (${worker.id}) | LOC: ${kitchen.code}</div>
                <div id="wm-gps">GPS: Lat 12.9856° N, Lng 77.5543° E | ACCURACY: ±4m</div>
                <div id="wm-time">TIME: ${new Date().toLocaleString()} (IST)</div>
              </div>
            </div>
          </div>

          <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button class="btn btn-secondary" id="btn-start-cam" onclick="AkshayaWorkerView.startCamera()">
              📹 Start Camera
            </button>
            <button class="btn btn-primary" id="btn-capture-selfie" onclick="AkshayaWorkerView.captureSelfie()" style="display:none;">
              📸 Capture Live Selfie & Stamp GPS
            </button>
            <button class="btn btn-success" id="btn-submit-att" onclick="AkshayaWorkerView.submitAttendance('${worker.id}')" style="display:none;">
              ✅ Confirm & Submit Attendance
            </button>
          </div>

          <!-- Geofence & Anti-Spoof Status Box -->
          <div style="margin-top:16px; padding:12px; background:var(--accent-green-light); border-radius:var(--radius-sm); border:1px solid #C6E9D4;">
            <div style="display:flex; align-items:center; gap:8px; font-size:13px; font-weight:600; color:var(--accent-green); margin-bottom:4px;">
              <span>🛡️ Geofence Boundary Verification: PASS</span>
            </div>
            <div style="font-size:12px; color:var(--text-secondary); line-height:1.4;">
              • Designated Kitchen: <strong>${kitchen.name}</strong><br>
              • Current Distance: <strong>14 meters</strong> (Well within ${kitchen.geofenceRadius}m allowed)<br>
              • Mock Location Detector: <strong>No Mock Provider Detected (Hardware GPS Active)</strong>
            </div>
          </div>
        </div>

        <!-- Right Column: Today's Status & Task Checklist -->
        <div>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">📋 Today's Kitchen Duties</h3>
              <span class="badge badge-navy">Batch: Morning 05:00</span>
            </div>

            <ul style="list-style:none; display:flex; flex-direction:column; gap:12px; font-size:14px;">
              <li style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" checked style="width:18px; height:18px; accent-color:var(--primary-saffron);">
                <span>Steam Line Inspection & Pressure Valve Check</span>
              </li>
              <li style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" checked style="width:18px; height:18px; accent-color:var(--primary-saffron);">
                <span>Rice Deseeding & 3-Stage Wash Cycle</span>
              </li>
              <li style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" checked style="width:18px; height:18px; accent-color:var(--primary-saffron);">
                <span>Vegetable Cutting Clean Room Sanitization</span>
              </li>
              <li style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" style="width:18px; height:18px; accent-color:var(--primary-saffron);">
                <span>Batch Cauldrons Temperature Logging (>80°C)</span>
              </li>
              <li style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" style="width:18px; height:18px; accent-color:var(--primary-saffron);">
                <span>Thermal Vessel Sealing & Dispatch Weigh-in</span>
              </li>
            </ul>
          </div>

          <!-- Quick Issue Report -->
          <div class="card" style="border-left:4px solid var(--status-amber);">
            <h4 style="font-size:15px; margin-bottom:6px; color:var(--accent-navy);">⚠️ Notice Any Defect or Breakdown?</h4>
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:12px;">
              Report boiler steam leak, water filter issue or vehicle delay directly to Area Supervisor.
            </p>
            <button class="btn btn-outline" style="width:100%; border-color:var(--status-amber); color:var(--status-amber);" onclick="AkshayaWorkerView.showReportIssueModal()">
              📢 Instant Kitchen Issue Report
            </button>
          </div>
        </div>
      </div>
    `;
  },

  renderPhotoCheckTab: function(kitchen) {
    var checkPoints = [
      { id: 1, title: "1. Kitchen Floor & Drainage Gutters", req: "Clean, dry walkways and grease-free drains", status: "Approved", time: "05:15 AM", img: "photo_floor.jpg" },
      { id: 2, title: "2. Cooking Utensils & Cauldrons", req: "Steam sanitized, shiny stainless steel, no food residue", status: "Approved", time: "05:25 AM", img: "photo_cauldrons.jpg" },
      { id: 3, title: "3. Staff Uniform, Cap, Apron & Gloves", req: "All staff in clean PPE with hair fully covered", status: "Approved", time: "05:35 AM", img: "photo_ppe.jpg" },
      { id: 4, title: "4. Raw Material Cold Storage & Pantry", req: "Vegetables elevated on crates, cold room < 4°C", status: "Needs Improvement", time: "06:05 AM", img: "photo_storage.jpg" },
      { id: 5, title: "5. Waste Segregation & Disposal Bins", req: "Lidded bins, organic vs dry segregation labeled", status: "Pending Upload", time: "--", img: null },
      { id: 6, title: "6. Water Filtration & Storage Tanks", req: "RO filter log logged, sealed overhead tank lids", status: "Pending Upload", time: "--", img: null },
      { id: 7, title: "7. Delivery Vehicle Cargo Bay & Seals", req: "Insulated bay washed, rubber seals clean & tight", status: "Pending Upload", time: "--", img: null }
    ];

    return `
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">📸 7-Point Mandatory Daily Hygiene Photo Upload</h3>
            <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
              Must be submitted daily before 07:00 AM dispatch. Each photo is auto-watermarked with GPS & timestamp.
            </p>
          </div>
          <span class="badge badge-saffron">4 of 7 Completed</span>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px;">
          ${checkPoints.map(cp => `
            <div style="border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:14px; background:#FAFAFA; display:flex; flex-direction:column; justify-content:space-between;">
              <div>
                <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:6px;">
                  <h4 style="font-size:14px; color:var(--accent-navy);">${cp.title}</h4>
                  <span class="badge ${cp.status === 'Approved' ? 'badge-green' : (cp.status === 'Needs Improvement' ? 'badge-red' : 'badge-amber')}" style="font-size:11px;">
                    ${cp.status}
                  </span>
                </div>
                <p style="font-size:12px; color:var(--text-secondary); margin-bottom:12px;">${cp.req}</p>
                <div style="background:#E2E8F0; border-radius:var(--radius-sm); height:120px; display:flex; align-items:center; justify-content:center; color:#64748B; font-size:12px; margin-bottom:10px; position:relative; overflow:hidden;">
                  ${cp.img ? `
                    <div style="background:linear-gradient(45deg, #1B2A41, #3B5274); width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:#FFF; font-weight:600;">
                      📷 [Photo Verified: ${cp.time}]
                    </div>
                  ` : `
                    <span>[Click 'Upload' or 'Take Photo']</span>
                  `}
                </div>
              </div>

              <div style="display:flex; gap:6px;">
                <button class="btn btn-primary" style="flex:1; padding:6px 10px; font-size:12px;" onclick="AkshayaWorkerView.simulatePhotoUpload(${cp.id})">
                  📷 Capture Photo
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  renderCalendarTab: function(worker) {
    return `
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">🗓️ Monthly Attendance & Punctuality Record</h3>
          <span class="badge badge-green">October 2026: 96.2% Attendance</span>
        </div>

        <div style="display:flex; gap:16px; margin-bottom:16px; font-size:13px;">
          <span style="display:flex; align-items:center; gap:6px;"><span class="status-dot green"></span> Present (24 Days)</span>
          <span style="display:flex; align-items:center; gap:6px;"><span class="status-dot amber"></span> Late Arrival (1 Day)</span>
          <span style="display:flex; align-items:center; gap:6px;"><span class="status-dot red"></span> Leave / Absent (1 Day)</span>
        </div>

        <div style="display:grid; grid-template-columns:repeat(7, 1fr); gap:6px; text-align:center; font-size:12px;">
          ${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => `<div style="font-weight:700; color:var(--text-secondary); padding:6px;">${d}</div>`).join('')}
          ${Array.from({ length: 31 }, (_, i) => {
            var day = i + 1;
            var isToday = day === 29;
            var isLate = day === 14;
            var isLeave = day === 18;
            var bg = isLeave ? '#FEE2E2' : (isLate ? '#FEF3C7' : '#DCFCE7');
            var color = isLeave ? '#991B1B' : (isLate ? '#92400E' : '#166534');
            return `
              <div style="background:${bg}; color:${color}; padding:10px 4px; border-radius:6px; font-weight:${isToday ? '700' : '500'}; border:${isToday ? '2px solid #F28C28' : 'none'};">
                ${day}
                <div style="font-size:10px;">${isLeave ? 'Leave' : (isLate ? '06:14' : '04:58')}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  },

  startCamera: function() {
    var video = document.getElementById('webcam-preview');
    var placeholder = document.getElementById('camera-placeholder');
    var btnStart = document.getElementById('btn-start-cam');
    var btnCapture = document.getElementById('btn-capture-selfie');
    var wmBox = document.getElementById('watermark-box');

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } })
        .then(stream => {
          this.cameraStream = stream;
          video.srcObject = stream;
          video.style.display = 'block';
          placeholder.style.display = 'none';
          btnStart.style.display = 'none';
          btnCapture.style.display = 'inline-flex';
          wmBox.style.display = 'block';
        })
        .catch(err => {
          // Camera permission denied or unsupported environment (simulate preview canvas)
          this.simulateCameraStream();
        });
    } else {
      this.simulateCameraStream();
    }
  },

  simulateCameraStream: function() {
    var placeholder = document.getElementById('camera-placeholder');
    var btnStart = document.getElementById('btn-start-cam');
    var btnCapture = document.getElementById('btn-capture-selfie');
    var wmBox = document.getElementById('watermark-box');

    placeholder.innerHTML = `
      <div style="background:linear-gradient(135deg, #1B2A41 0%, #2A4365 100%); width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; color:#FFF; padding:20px;">
        <span style="font-size:54px;">👨‍🍳</span>
        <p style="font-weight:600; font-size:15px; margin-top:8px;">Live Front Camera Stream (Simulated)</p>
        <p style="font-size:12px; color:#CBD5E1;">GPS Hardware Lock: 12.9856° N, 77.5543° E (±3m)</p>
      </div>
    `;
    btnStart.style.display = 'none';
    btnCapture.style.display = 'inline-flex';
    wmBox.style.display = 'block';
  },

  captureSelfie: function() {
    var canvas = document.getElementById('selfie-canvas');
    var video = document.getElementById('webcam-preview');
    var btnCapture = document.getElementById('btn-capture-selfie');
    var btnSubmit = document.getElementById('btn-submit-att');

    canvas.width = 480;
    canvas.height = 360;
    var ctx = canvas.getContext('2d');

    if (this.cameraStream && video.style.display !== 'none') {
      ctx.drawImage(video, 0, 0, 480, 360);
      this.stopCamera();
    } else {
      // Draw simulated frame
      ctx.fillStyle = '#1B2A41';
      ctx.fillRect(0, 0, 480, 360);
      ctx.font = 'bold 24px sans-serif';
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.fillText('👨‍🍳 Basavaraju M. (Head Cook)', 240, 160);
    }

    // Burn Watermark directly into canvas pixels (Anti-tamper)
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, 290, 480, 70);
    ctx.font = '11px monospace';
    ctx.fillStyle = '#F28C28';
    ctx.textAlign = 'left';
    ctx.fillText('AKSHAYA SEVA FOUNDATION - VERIFIED BIOMETRIC STAMP', 12, 310);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText('LOC: BLR-01 Mega Kitchen | GPS: 12.9856N, 77.5543E | DIST: 14m', 12, 326);
    ctx.fillText('TIMESTAMP: ' + new Date().toISOString() + ' (ANTI-SPOOF PASS)', 12, 342);

    canvas.style.display = 'block';
    if (video) video.style.display = 'none';
    btnCapture.style.display = 'none';
    btnSubmit.style.display = 'inline-flex';

    window.AkshayaNotify.toast("Selfie Captured & Watermarked with GPS Coordinates!", "success");
  },

  submitAttendance: function(workerId) {
    var timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    var target = window.AkshayaData.workers.find(w => w.id === workerId) || window.AkshayaData.workers[0];

    target.todayAttendance = {
      status: "Present",
      checkInTime: timeStr,
      checkOutTime: null,
      lat: 12.9856,
      lng: 77.5543,
      verified: true,
      selfieUrl: "selfie_watermarked.png",
      geofenceDistanceMeters: 14
    };

    window.AkshayaSync.broadcast('WORKER_CHECKIN', {
      workerId: target.id,
      workerName: target.name,
      time: timeStr,
      distance: 14
    });

    window.AkshayaNotify.toast(`Attendance Recorded! Welcome to duty, ${target.name}.`, "success");
    if (window.renderApp) window.renderApp();
  },

  simulatePhotoUpload: function(id) {
    window.AkshayaNotify.toast(`Photo #${id} uploaded and stamped with GPS Lat/Lng & 06:15 AM!`, "success");
  },

  showLeaveModal: function() {
    window.AkshayaNotify.alertModal(
      "📅 Apply for Scheduled Leave",
      `Submit leave request for Area Supervisor approval:\n\nType: Casual / Medical\nDates: Enter start & end date\nHandover: Assigned to Assistant Cook Gangamma H.\n\n[Form saved to supervisor approval inbox]`
    );
  },

  showReportIssueModal: function() {
    window.AkshayaNotify.alertModal(
      "⚠️ Report Kitchen Breakdown",
      `Quick issue dispatch to Maintenance & Supervisor:\n\nCategories: Boiler Steam Leak | Water Filter | Electricity | Vehicle Delay\n\nNotification dispatched instantly to Anand Rao (Area Supervisor).`
    );
  },

  stopCamera: function() {
    if (this.cameraStream) {
      this.cameraStream.getTracks().forEach(t => t.stop());
      this.cameraStream = null;
    }
  }
};
