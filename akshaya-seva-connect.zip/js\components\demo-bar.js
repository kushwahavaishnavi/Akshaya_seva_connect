// Interactive Demo Controls Bar & Simulation Suite
window.AkshayaDemoBar = {
  render: function() {
    var app = window.AkshayaApp;
    var currentRole = app ? app.currentRole : 'admin';
    var layout = app ? app.currentLayout : 'split';
    var lang = window.AkshayaI18n.currentLang;

    return `
      <div class="demo-banner">
        <div class="demo-title-group">
          <span>🛡️ <strong>Akshaya Seva Connect</strong> | Live Ops Simulator</span>
          <span class="badge badge-saffron" style="background:#FFF0DE;color:#D67417;font-size:11px;">Real-Time Synced</span>
        </div>

        <div class="demo-actions">
          <!-- Role Switcher -->
          <label style="font-size:12px;display:flex;align-items:center;gap:4px;">
            <span>Role:</span>
            <select id="demo-role-select" onchange="AkshayaApp.setRole(this.value)" class="form-select" style="padding:3px 8px;font-size:12px;width:auto;background:#2A3F60;color:#FFF;border-color:#486581;">
              <option value="worker" ${currentRole === 'worker' ? 'selected' : ''}>👨‍🍳 Worker (Kitchen Staff)</option>
              <option value="driver" ${currentRole === 'driver' ? 'selected' : ''}>🚚 Driver (Delivery Staff)</option>
              <option value="school" ${currentRole === 'school' ? 'selected' : ''}>🏫 School Rep (Teacher)</option>
              <option value="supervisor" ${currentRole === 'supervisor' ? 'selected' : ''}>📋 Kitchen Supervisor</option>
              <option value="supplier" ${currentRole === 'supplier' ? 'selected' : ''}>🌾 Raw Material Supplier</option>
              <option value="admin" ${currentRole === 'admin' ? 'selected' : ''}>🏢 Admin / Management</option>
              <option value="hq" ${currentRole === 'hq' ? 'selected' : ''}>🏛️ Headquarters (HQ)</option>
              <option value="public" ${currentRole === 'public' ? 'selected' : ''}>📢 Public (Raise / Track)</option>
            </select>
          </label>

          <!-- Layout Switcher (for Split view) -->
          <div style="display:flex;align-items:center;gap:4px;">
            <button class="demo-btn ${layout === 'split' ? 'active' : ''}" onclick="AkshayaApp.setLayout('split')" title="50/50 Dual Admin + HQ Split Screen">
              🔀 50/50 Split
            </button>
            <button class="demo-btn ${layout === 'admin_full' ? 'active' : ''}" onclick="AkshayaApp.setLayout('admin_full')" title="Full Admin Screen">
              🏢 Admin Full
            </button>
            <button class="demo-btn ${layout === 'hq_full' ? 'active' : ''}" onclick="AkshayaApp.setLayout('hq_full')" title="Full HQ Screen">
              🏛️ HQ Full
            </button>
          </div>

          <!-- Simulation Triggers -->
          <div style="display:flex;align-items:center;gap:4px;">
            <button class="demo-btn" onclick="AkshayaDemoBar.simulateWorkerCheckIn()" title="Simulates a worker GPS + Selfie Check-in">
              ⚡ Sim Check-In
            </button>
            <button class="demo-btn" onclick="AkshayaDemoBar.simulateShortage()" title="Simulates a food shortage incident on Route 1A">
              ⚠️ Sim Shortage
            </button>
            <button class="demo-btn sos-btn" onclick="AkshayaDemoBar.simulateCriticalComplaint()" title="Triggers emergency SOS foreign-matter alert">
              🚨 Sim Critical SOS
            </button>
            <button class="demo-btn" style="background:#1F7A4D;" onclick="AkshayaDemoBar.simulateGenerateReportHQ()" title="Compiles Day Report and Submits to HQ">
              📋 Submit to HQ
            </button>
          </div>

          <!-- Language Selector -->
          <select onchange="AkshayaI18n.setLanguage(this.value)" class="form-select" style="padding:3px 8px;font-size:12px;width:auto;background:#2A3F60;color:#FFF;border-color:#486581;">
            ${window.AkshayaI18n.languages.map(l => `<option value="${l.code}" ${l.code === lang ? 'selected' : ''}>${l.native}</option>`).join('')}
          </select>

          <!-- Voice Assist Button -->
          <button class="demo-btn" onclick="AkshayaDemoBar.speakSummary()" title="Read aloud current operational status">
            🔊 Voice Assist
          </button>
        </div>
      </div>
    `;
  },

  simulateWorkerCheckIn: function() {
    var workers = window.AkshayaData.workers;
    var target = workers.find(w => w.todayAttendance.status !== 'Present');
    if (!target) target = workers[7]; // Sowmya Rani

    var timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    target.todayAttendance = {
      status: "Present",
      checkInTime: timeStr,
      checkOutTime: null,
      lat: 12.9856 + (Math.random() - 0.5) * 0.001,
      lng: 77.5543 + (Math.random() - 0.5) * 0.001,
      verified: true,
      selfieUrl: "selfie_live.jpg",
      geofenceDistanceMeters: Math.floor(Math.random() * 25) + 5
    };

    window.AkshayaSync.broadcast('WORKER_CHECKIN', {
      workerId: target.id,
      workerName: target.name,
      time: timeStr,
      distance: target.todayAttendance.geofenceDistanceMeters
    });

    window.AkshayaNotify.toast(`Worker ${target.name} Checked-in with Live GPS Selfie (${target.todayAttendance.geofenceDistanceMeters}m from kitchen)`, "success");
    if (window.renderApp) window.renderApp();
  },

  simulateShortage: function() {
    var k1 = window.AkshayaData.kitchens[0];
    var shortageKg = 25.0;
    var expectedKg = 1250.0;
    var shortagePct = ((shortageKg / expectedKg) * 100).toFixed(1);

    var shortageRecord = {
      id: "SHT-" + Date.now().toString().substr(-5),
      timestamp: new Date().toLocaleTimeString(),
      route: "Route 1A (North)",
      school: "Dr. B.R. Ambedkar Model School, Yeshwanthpur",
      driver: "Ramesh Gowda",
      vehicleNo: "KA-01-MJ-4521",
      expectedKg: expectedKg,
      shortageKg: shortageKg,
      shortagePercent: shortagePct,
      reason: "Unexpected extra student enrollment from neighboring rural cluster camp",
      emergencyResponse: "Buffer thermal vessel dispatched from Rajajinagar hub"
    };

    window.AkshayaSync.broadcast('SHORTAGE_REPORTED', shortageRecord);
    window.AkshayaNotify.toast(`Food Shortage Reported on Route 1A: ${shortageKg} kg (${shortagePct}%). Buffer container dispatched!`, "warning");
    if (window.renderApp) window.renderApp();
  },

  simulateCriticalComplaint: function() {
    // Play synthetic beep alert sound
    this.playEmergencyBeep();

    var ticket = {
      id: "TKT-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toISOString(),
      complainantName: "School SMC President",
      role: "Public / School SMC",
      schoolName: "Chamundi Kripa Tribal Residential School, Mysuru",
      kitchenId: "K3",
      category: "Critical / Foreign Object",
      priority: "Critical",
      description: "CRITICAL: Foreign element reported in sambar batch. Service paused immediately for sample test.",
      status: "Open",
      assignedTo: "HQ Safety Cell & Mysuru Supervisor Rajesh Kumar",
      slaDeadline: new Date(Date.now() + 3600000).toISOString(),
      isCriticalAlert: true
    };

    window.AkshayaData.complaints.unshift(ticket);

    window.AkshayaSync.broadcast('CRITICAL_ALERT', ticket);
    window.AkshayaNotify.alertModal(
      "🚨 CRITICAL FOOD SAFETY ALERT",
      `Ticket #${ticket.id} raised at ${ticket.schoolName}.\n\nCategory: Foreign Object.\nAction: Food serving suspended pending supervisor microbiological sample verification.\nInstant alerts dispatched to HQ Operations Director and Kitchen Lead!`
    );

    if (window.renderApp) window.renderApp();
  },

  simulateGenerateReportHQ: function() {
    var todayStr = new Date().toISOString().split('T')[0];
    var report = {
      id: "REP-" + todayStr + "-CONSOLIDATED",
      date: todayStr,
      kitchenName: "All 3 Operating Kitchens (Statewide Consolidated)",
      submittedBy: "State Admin Anand Rao",
      submittedAt: new Date().toISOString(),
      totalFed: 54100,
      onTimeDeliveryRate: "98.8%",
      shortageRate: "0.2%",
      hygieneScore: 91,
      status: "Submitted to HQ",
      hqComments: null,
      details: "Statewide operations covering 10 model schools across Bengaluru, Hubballi and Mysuru. All thermal limits (>65°C) maintained."
    };

    window.AkshayaData.hqInbox.unshift({
      id: "HQ-" + report.id,
      reportId: report.id,
      kitchenName: report.kitchenName,
      submittedBy: report.submittedBy,
      submittedAt: report.submittedAt,
      totalFed: report.totalFed,
      onTimeDeliveryRate: report.onTimeDeliveryRate,
      shortageRate: report.shortageRate,
      hygieneScore: report.hygieneScore,
      status: "Pending HQ Review",
      isNew: true
    });

    window.AkshayaSync.broadcast('REPORT_SUBMITTED_HQ', report);
    window.AkshayaNotify.toast(`Consolidated Mid-Day Meal Report submitted to Headquarters!`, "success");
    if (window.renderApp) window.renderApp();
  },

  playEmergencyBeep: function() {
    try {
      var audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
      osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.4);
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.4);
    } catch(e) {}
  },

  speakSummary: function() {
    var t = window.AkshayaI18n.t.bind(window.AkshayaI18n);
    var summary = `${t('appName')}. Today, 54,100 children were served nutritious hot mid-day meals across Karnataka. Average kitchen hygiene score is 91 percent. All delivery routes are GPS tracked and temperature verified.`;
    window.AkshayaI18n.speakText(summary);
  }
};
