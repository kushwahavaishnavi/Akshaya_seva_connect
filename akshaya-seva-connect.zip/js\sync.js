// Real-time Event Bus & Cross-Window Synchronizer
window.AkshayaSync = {
  channelName: 'akshaya_sync_bus',
  channel: null,
  listeners: [],
  sseSource: null,

  init: function() {
    var self = this;
    if ('BroadcastChannel' in window) {
      try {
        this.channel = new BroadcastChannel(this.channelName);
        this.channel.onmessage = function(event) {
          self.handleIncomingEvent(event.data, false);
        };
      } catch(e) {
        console.warn("BroadcastChannel error", e);
      }
    }

    // Storage fallback for cross-tab sync
    window.addEventListener('storage', function(e) {
      if (e.key === 'akshaya_last_broadcast_event' && e.newValue) {
        try {
          var payload = JSON.parse(e.newValue);
          self.handleIncomingEvent(payload, false);
        } catch(err) {}
      }
    });

    // Optional Server-Sent Events connection
    this.connectSSE();
  },

  connectSSE: function() {
    var self = this;
    try {
      if ('EventSource' in window) {
        this.sseSource = new EventSource('/api/events');
        this.sseSource.onmessage = function(event) {
          try {
            var data = JSON.parse(event.data);
            self.handleIncomingEvent(data, false);
          } catch(e) {}
        };
        this.sseSource.onerror = function() {
          // Keep silent, fallback to BroadcastChannel
        };
      }
    } catch(e) {}
  },

  broadcast: function(eventType, payload) {
    var envelope = {
      type: eventType,
      payload: payload,
      timestamp: new Date().toISOString(),
      senderId: window.AkshayaApp ? window.AkshayaApp.clientId : 'client-01'
    };

    // 1. Dispatch locally in this window/view
    this.handleIncomingEvent(envelope, true);

    // 2. Dispatch to other browser tabs/windows
    if (this.channel) {
      try {
        this.channel.postMessage(envelope);
      } catch(e) {}
    }

    // 3. Update localStorage for storage event trigger
    try {
      localStorage.setItem('akshaya_last_broadcast_event', JSON.stringify(envelope));
    } catch(e) {}

    // 4. Send to Node server if reachable
    fetch('/api/broadcast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(envelope)
    }).catch(function() {});
  },

  subscribe: function(callback) {
    this.listeners.push(callback);
    return function() {
      var idx = window.AkshayaSync.listeners.indexOf(callback);
      if (idx > -1) window.AkshayaSync.listeners.splice(idx, 1);
    };
  },

  handleIncomingEvent: function(envelope, isLocal) {
    if (!envelope || !envelope.type) return;
    
    // Call all registered listeners
    for (var i = 0; i < this.listeners.length; i++) {
      try {
        this.listeners[i](envelope, isLocal);
      } catch(e) {
        console.error("Listener error", e);
      }
    }
  }
};
