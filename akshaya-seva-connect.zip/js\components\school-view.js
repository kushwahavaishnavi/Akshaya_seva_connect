// School Representative Interface: Delivery Confirmation, Signature & Emoji Feedback
window.AkshayaSchoolView = {
  sigPadInitialized: false,
  isDrawing: false,
  selectedEmoji: '😋',

  render: function() {
    var school = window.AkshayaData.schools[0]; // Malleshwaram
    var kitchen = window.AkshayaData.kitchens.find(k => k.id === school.kitchenId);

    setTimeout(() => {
      this.initSignaturePad();
    }, 100);

    return `
      <div class="single-panel-layout">
        <!-- School Profile Header -->
        <div class="card" style="background: linear-gradient(135deg, #F0FDF4 0%, #FFFFFF 100%); border-left: 5px solid var(--accent-green);">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:var(--accent-green); color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                🏫
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">${school.name}</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span class="badge badge-green">In-Charge: ${school.contactPerson}</span>
                  <span>Enrolled: <strong>${school.enrolled} Students</strong></span>
                  <span>Kitchen: ${kitchen ? kitchen.name : 'Central Hub'}</span>
                </div>
              </div>
            </div>

            <div style="display:flex; gap:10px;">
              <button class="btn btn-outline" style="border-color:var(--status-red); color:var(--status-red);" onclick="AkshayaApp.setRole('public')">
                📢 Raise Complaint
              </button>
            </div>
          </div>
        </div>

        <!-- Food Receipt & Acknowledgement Form -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">🍲 Confirm Today's Meal Delivery</h3>
              <span class="badge badge-green">Received: 11:42 AM</span>
            </div>

            <form onsubmit="event.preventDefault(); AkshayaSchoolView.submitAcknowledgement();">
              <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px;">
                <div class="form-group">
                  <label class="form-label">Total Students Enrolled</label>
                  <input type="number" class="form-input" value="${school.enrolled}" readonly style="background:#F1F5F9;">
                </div>

                <div class="form-group">
                  <label class="form-label">Actual Children Fed Today</label>
                  <input type="number" class="form-input" id="sch-fed-count" value="412" required>
                </div>
              </div>

              <div class="form-group">
                <label class="form-label">Food Quality & Taste (1 - 5 Stars)</label>
                <select class="form-select" id="sch-star-rating">
                  <option value="5" selected>⭐⭐⭐⭐⭐ 5 Stars - Excellent Warmth & Taste</option>
                  <option value="4">⭐⭐⭐⭐ 4 Stars - Good & Palatable</option>
                  <option value="3">⭐⭐⭐ 3 Stars - Average</option>
                  <option value="2">⭐⭐ 2 Stars - Substandard (Requires Attention)</option>
                  <option value="1">⭐ 1 Star - Unacceptable (Raise Incident)</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Teacher / Headmistress Digital Signature</label>
                <div style="position:relative;">
                  <canvas id="school-sig-canvas" class="signature-canvas"></canvas>
                  <button type="button" class="btn btn-outline" style="position:absolute; bottom:8px; right:8px; padding:4px 8px; font-size:11px;" onclick="AkshayaSchoolView.clearSignature()">
                    Clear Signature
                  </button>
                </div>
                <small style="color:var(--text-muted); font-size:11px;">Sign with finger on touchscreen or cursor</small>
              </div>

              <button type="submit" class="btn btn-primary" style="width:100%; background:var(--accent-green);">
                ✅ Acknowledge & Lock Delivery Receipt
              </button>
            </form>
          </div>

          <!-- Right Column: Children's Emoji Feedback & Food Info -->
          <div>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">🧒 Children's Meal Satisfaction Emoji Poll</h3>
                <span class="badge badge-saffron">Collected in Classroom</span>
              </div>

              <p style="font-size:13px; color:var(--text-secondary); margin-bottom:16px;">
                Ask student monitors to tap the emoji that best reflects today's meal enjoyment:
              </p>

              <div style="display:flex; justify-content:space-around; align-items:center; margin-bottom:20px;">
                <div class="emoji-btn" onclick="AkshayaSchoolView.selectEmoji('😋')" style="cursor:pointer; text-align:center; padding:12px; border-radius:12px; background:${this.selectedEmoji === '😋' ? '#FEF3C7' : '#F8FAFC'}; border:2px solid ${this.selectedEmoji === '😋' ? '#F59E0B' : '#E2E8F0'}; transition:transform 0.15s;">
                  <div style="font-size:38px;">😋</div>
                  <div style="font-size:12px; font-weight:600; color:var(--accent-navy); margin-top:4px;">Delicious!</div>
                  <span style="font-size:11px; color:#166534;">78% Votes</span>
                </div>

                <div class="emoji-btn" onclick="AkshayaSchoolView.selectEmoji('😊')" style="cursor:pointer; text-align:center; padding:12px; border-radius:12px; background:${this.selectedEmoji === '😊' ? '#FEF3C7' : '#F8FAFC'}; border:2px solid ${this.selectedEmoji === '😊' ? '#F59E0B' : '#E2E8F0'}; transition:transform 0.15s;">
                  <div style="font-size:38px;">😊</div>
                  <div style="font-size:12px; font-weight:600; color:var(--accent-navy); margin-top:4px;">Good</div>
                  <span style="font-size:11px; color:var(--text-secondary);">18% Votes</span>
                </div>

                <div class="emoji-btn" onclick="AkshayaSchoolView.selectEmoji('😐')" style="cursor:pointer; text-align:center; padding:12px; border-radius:12px; background:${this.selectedEmoji === '😐' ? '#FEF3C7' : '#F8FAFC'}; border:2px solid ${this.selectedEmoji === '😐' ? '#F59E0B' : '#E2E8F0'}; transition:transform 0.15s;">
                  <div style="font-size:38px;">😐</div>
                  <div style="font-size:12px; font-weight:600; color:var(--accent-navy); margin-top:4px;">Okay</div>
                  <span style="font-size:11px; color:var(--text-secondary);">3% Votes</span>
                </div>

                <div class="emoji-btn" onclick="AkshayaSchoolView.selectEmoji('😞')" style="cursor:pointer; text-align:center; padding:12px; border-radius:12px; background:${this.selectedEmoji === '😞' ? '#FEF3C7' : '#F8FAFC'}; border:2px solid ${this.selectedEmoji === '😞' ? '#F59E0B' : '#E2E8F0'}; transition:transform 0.15s;">
                  <div style="font-size:38px;">😞</div>
                  <div style="font-size:12px; font-weight:600; color:var(--accent-navy); margin-top:4px;">Less Salt</div>
                  <span style="font-size:11px; color:var(--status-red);">1% Votes</span>
                </div>
              </div>

              <div style="padding:12px; background:var(--bg-offwhite); border-radius:var(--radius-sm); border:1px solid var(--border-color); font-size:12px;">
                <strong>Today's Menu Served:</strong> Steamed Fortified Rice, Drumstick Pumpkin Sambar, Sweet Pongal & Banana.<br>
                <strong>Delivery Vehicle:</strong> KA-01-MJ-4521 (Ramesh Gowda) | Arrived at 74°C
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  initSignaturePad: function() {
    var canvas = document.getElementById('school-sig-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    ctx.strokeStyle = '#1B2A41';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';

    // Draw initial sample cursive signature
    ctx.font = 'italic 28px "Caveat", "Brush Script MT", cursive';
    ctx.fillStyle = '#1B2A41';
    ctx.fillText('Smt. Shylaja Devi (HM)', 40, 90);

    var self = this;
    function getPos(e) {
      var rect = canvas.getBoundingClientRect();
      var clientX = e.touches ? e.touches[0].clientX : e.clientX;
      var clientY = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: clientX - rect.left, y: clientY - rect.top };
    }

    canvas.onmousedown = function(e) {
      self.isDrawing = true;
      var pos = getPos(e);
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    };

    canvas.onmousemove = function(e) {
      if (!self.isDrawing) return;
      var pos = getPos(e);
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    };

    window.onmouseup = function() {
      self.isDrawing = false;
    };
  },

  clearSignature: function() {
    var canvas = document.getElementById('school-sig-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  },

  selectEmoji: function(emoji) {
    this.selectedEmoji = emoji;
    window.AkshayaNotify.toast(`Children's rating ${emoji} captured for today's dish!`, "success");
    if (window.renderApp) window.renderApp();
  },

  submitAcknowledgement: function() {
    var count = document.getElementById('sch-fed-count').value;
    var stars = document.getElementById('sch-star-rating').value;

    window.AkshayaSync.broadcast('SCHOOL_ACKNOWLEDGED', {
      schoolId: 'S1',
      schoolName: 'Govt Higher Primary School, Malleshwaram',
      childrenFed: count,
      rating: stars,
      emoji: this.selectedEmoji,
      signedBy: 'Smt. Shylaja Devi'
    });

    window.AkshayaNotify.toast(`Delivery receipt acknowledged: ${count} children fed. Digital signature stored!`, "success");
  }
};
