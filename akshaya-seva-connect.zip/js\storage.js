// Offline Storage, IndexedDB & Background Sync Engine
window.AkshayaStorage = {
  dbName: 'AkshayaSevaOfflineDB',
  dbVersion: 1,
  db: null,
  isOnline: navigator.onLine,
  syncQueue: [],

  init: function() {
    var self = this;
    window.addEventListener('online', function() {
      self.isOnline = true;
      self.updateNetworkBadge();
      self.syncPendingQueue();
      if (window.AkshayaNotify) {
        window.AkshayaNotify.toast("Network Connection Restored! Syncing queued records...", "success");
      }
    });

    window.addEventListener('offline', function() {
      self.isOnline = false;
      self.updateNetworkBadge();
      if (window.AkshayaNotify) {
        window.AkshayaNotify.toast("You are currently offline. Operations will be saved to IndexedDB.", "warning");
      }
    });

    return new Promise(function(resolve, reject) {
      if (!window.indexedDB) {
        console.warn("IndexedDB not supported, falling back to LocalStorage");
        self.loadQueueFromLocalStorage();
        resolve(self);
        return;
      }

      var request = window.indexedDB.open(self.dbName, self.dbVersion);
      request.onupgradeneeded = function(e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains('syncQueue')) {
          db.createObjectStore('syncQueue', { keyPath: 'id', autoIncrement: true });
        }
        if (!db.objectStoreNames.contains('drafts')) {
          db.createObjectStore('drafts', { keyPath: 'key' });
        }
      };

      request.onsuccess = function(e) {
        self.db = e.target.result;
        self.loadQueueFromDB();
        resolve(self);
      };

      request.onerror = function(err) {
        console.error("IndexedDB open failed", err);
        self.loadQueueFromLocalStorage();
        resolve(self);
      };
    });
  },

  updateNetworkBadge: function() {
    var badge = document.getElementById('network-status-badge');
    if (!badge) return;
    if (this.isOnline) {
      badge.innerHTML = '<span class="status-dot green"></span> <span class="badge-text">Online</span>';
      badge.className = 'status-chip online';
    } else {
      var queueCount = this.syncQueue.length;
      badge.innerHTML = '<span class="status-dot amber"></span> <span class="badge-text">Offline (' + queueCount + ' Queued)</span>';
      badge.className = 'status-chip offline';
    }
  },

  enqueue: function(actionType, payload) {
    var item = {
      id: Date.now() + '-' + Math.random().toString(36).substr(2, 6),
      type: actionType,
      payload: payload,
      timestamp: new Date().toISOString()
    };
    this.syncQueue.push(item);
    this.saveQueue();
    this.updateNetworkBadge();

    // If online, try syncing right away
    if (this.isOnline) {
      this.syncPendingQueue();
    }
  },

  saveQueue: function() {
    try {
      localStorage.setItem('akshaya_sync_queue', JSON.stringify(this.syncQueue));
    } catch(e) {}
  },

  loadQueueFromLocalStorage: function() {
    try {
      var q = localStorage.getItem('akshaya_sync_queue');
      this.syncQueue = q ? JSON.parse(q) : [];
      this.updateNetworkBadge();
    } catch(e) {
      this.syncQueue = [];
    }
  },

  loadQueueFromDB: function() {
    this.loadQueueFromLocalStorage();
  },

  syncPendingQueue: function() {
    if (!this.syncQueue.length) return;
    var self = this;
    var queueCopy = self.syncQueue.slice();

    // Broadcast or push items to server
    fetch('/api/sync-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: queueCopy })
    }).then(function(res) {
      return res.json();
    }).then(function(data) {
      self.syncQueue = [];
      self.saveQueue();
      self.updateNetworkBadge();
      if (window.AkshayaNotify) {
        window.AkshayaNotify.toast("Synced " + queueCopy.length + " items to central server!", "success");
      }
    }).catch(function(err) {
      console.warn("Central server offline or sandboxed, items retained in local storage bus", err);
      // Items remain queued for retry
    });
  },

  saveDraft: function(key, data) {
    try {
      localStorage.setItem('draft_' + key, JSON.stringify(data));
    } catch(e) {}
  },

  getDraft: function(key) {
    try {
      var d = localStorage.getItem('draft_' + key);
      return d ? JSON.parse(d) : null;
    } catch(e) {
      return null;
    }
  },

  clearDraft: function(key) {
    try {
      localStorage.removeItem('draft_' + key);
    } catch(e) {}
  }
};
