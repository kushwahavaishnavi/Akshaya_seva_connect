// Dual Split-View Synchronizer: Admin (Saffron) & HQ (Navy) Live Co-Existence
window.AkshayaSplitView = {
  render: function() {
    return `
      <div>
        <!-- Dual Split Panel Header Explanation -->
        <div style="background:#FFF; padding:12px 18px; border-radius:var(--radius-sm); border:1px solid var(--border-color); margin-bottom:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
          <div style="font-size:13px; color:var(--text-secondary);">
            ⚡ <strong>Dual Screen Sync Mode Active:</strong> Field Admin (Saffron) on Left & National HQ (Navy) on Right. Submitting or acknowledging reports triggers instantaneous real-time sync with animations across both sides or across two browser windows!
          </div>
          <div style="display:flex; gap:8px;">
            <button class="btn btn-outline" style="font-size:12px; padding:4px 10px;" onclick="window.open(window.location.href, '_blank')">
              🪟 Open In 2nd Window (Test Multi-Monitor Sync)
            </button>
          </div>
        </div>

        <div class="split-screen-container">
          <!-- LEFT PANEL: ADMIN / MANAGEMENT (Saffron Theme) -->
          <div class="split-panel admin-pane">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; padding-bottom:10px; border-bottom:2px solid var(--primary-saffron);">
              <div>
                <span class="badge badge-saffron" style="font-size:13px; padding:6px 12px;">
                  🏢 ADMIN OPERATIONS PANEL (Saffron)
                </span>
                <div style="font-size:12px; color:var(--text-secondary); margin-top:4px;">
                  Field Management, GPS Audits & Report Generation
                </div>
              </div>
              <button class="btn btn-primary" style="font-size:12px; padding:6px 12px;" onclick="AkshayaDemoBar.simulateGenerateReportHQ()">
                📋 Submit Report to HQ
              </button>
            </div>

            <!-- Admin Content -->
            ${window.AkshayaAdminView.render()}
          </div>

          <!-- RIGHT PANEL: HEADQUARTERS (HQ) (Navy Theme) -->
          <div class="split-panel hq-pane">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; padding-bottom:10px; border-bottom:2px solid var(--accent-navy);">
              <div>
                <span class="badge badge-navy" style="font-size:13px; padding:6px 12px; background:#1B2A41; color:#FFF;">
                  🏛️ HEADQUARTERS COMMAND (Navy)
                </span>
                <div style="font-size:12px; color:var(--text-secondary); margin-top:4px;">
                  Consolidated Real-Time Analytics & Approvals
                </div>
              </div>
              <div style="font-size:12px; color:var(--accent-green); font-weight:600; display:flex; align-items:center; gap:4px;">
                <span class="status-dot green"></span> Synced Stream
              </div>
            </div>

            <!-- HQ Content -->
            ${window.AkshayaHQView.render()}
          </div>
        </div>
      </div>
    `;
  }
};
