// Driver & Delivery Interface: Route Log, Thermal Check & Shortage Reporting
window.AkshayaDriverView = {
  render: function() {
    var driver = window.AkshayaData.drivers[0]; // Ramesh Gowda
    var schools = window.AkshayaData.schools.filter(s => driver.schoolsCovered.includes(s.id));

    return `
      <div class="single-panel-layout">
        <!-- Driver Vehicle Card -->
        <div class="card" style="background: linear-gradient(135deg, #EEF2F6 0%, #FFFFFF 100%); border-left: 5px solid var(--accent-navy);">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:var(--accent-navy); color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                🚚
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">${driver.name}</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span class="badge badge-navy">Vehicle: ${driver.vehicleNo}</span>
                  <span>📍 Route: ${driver.routeAssigned}</span>
                  <span class="badge badge-green">Status: ${driver.todayStatus}</span>
                </div>
              </div>
            </div>

            <div style="display:flex; gap:10px;">
              <button class="btn btn-outline" onclick="AkshayaDriverView.showThermalLog()">
                🌡️ Thermal Log
              </button>
              <button class="btn btn-primary" onclick="AkshayaDriverView.scrollToShortage()">
                ⚠️ Report Shortage
              </button>
            </div>
          </div>
        </div>

        <!-- Route & Delivery Sequence -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">🗺️ Today's Delivery Route & Timing</h3>
              <span class="badge badge-green">On Schedule</span>
            </div>

            <div style="display:flex; flex-direction:column; gap:16px;">
              <!-- Origin Hub -->
              <div style="display:flex; gap:12px; align-items:flex-start;">
                <div style="width:32px; height:32px; border-radius:50%; background:var(--primary-saffron); color:#FFF; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:14px; flex-shrink:0;">
                  0
                </div>
                <div style="flex:1;">
                  <div style="display:flex; justify-content:space-between;">
                    <strong style="color:var(--accent-navy);">BLR-01 Mega Kitchen (Rajajinagar)</strong>
                    <span style="font-size:12px; color:var(--accent-green); font-weight:600;">Dispatched 09:30 AM</span>
                  </div>
                  <p style="font-size:12px; color:var(--text-secondary);">Core food batch temp: 82°C | 24 Insulated Cauldrons loaded</p>
                </div>
              </div>

              <!-- Stop 1 -->
              <div style="display:flex; gap:12px; align-items:flex-start; padding-left:6px; border-left:2px dashed var(--primary-saffron); margin-left:14px;">
                <div style="width:28px; height:28px; border-radius:50%; background:var(--accent-green); color:#FFF; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:12px; flex-shrink:0; margin-left:-21px;">
                  1
                </div>
                <div style="flex:1; padding-bottom:12px;">
                  <div style="display:flex; justify-content:space-between;">
                    <strong style="color:var(--accent-navy);">${schools[0] ? schools[0].name : 'Govt School Malleshwaram'}</strong>
                    <span class="badge badge-green">Delivered 11:42 AM</span>
                  </div>
                  <p style="font-size:12px; color:var(--text-secondary);">412 Children Fed | Food Temp 74°C | Headmistress Signature Confirmed</p>
                </div>
              </div>

              <!-- Stop 2 -->
              <div style="display:flex; gap:12px; align-items:flex-start; padding-left:6px; border-left:2px dashed var(--accent-navy); margin-left:14px;">
                <div style="width:28px; height:28px; border-radius:50%; background:var(--accent-green); color:#FFF; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:12px; flex-shrink:0; margin-left:-21px;">
                  2
                </div>
                <div style="flex:1;">
                  <div style="display:flex; justify-content:space-between;">
                    <strong style="color:var(--accent-navy);">${schools[1] ? schools[1].name : 'Dr. B.R. Ambedkar Model School'}</strong>
                    <span class="badge badge-green">Delivered 11:58 AM</span>
                  </div>
                  <p style="font-size:12px; color:var(--text-secondary);">565 Children Fed | Food Temp 71°C | Zero delay</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Live Trip Metrics & Vehicle Diagnostics -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">🚛 Cargo Bay Thermal Telemetry</h3>
              <span class="badge badge-navy">Sensor ID: IOT-TH-4521</span>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px;">
              <div style="background:#F8FAFC; padding:14px; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
                <div style="font-size:12px; color:var(--text-secondary);">Dispatch Temperature</div>
                <div style="font-size:24px; font-weight:700; color:var(--primary-saffron-dark);">82.4 °C</div>
                <div style="font-size:11px; color:var(--accent-green); font-weight:600;">Standard (>65°C) OK</div>
              </div>

              <div style="background:#F8FAFC; padding:14px; border-radius:var(--radius-sm); border:1px solid var(--border-color);">
                <div style="font-size:12px; color:var(--text-secondary);">Last School Temp</div>
                <div style="font-size:24px; font-weight:700; color:var(--accent-navy);">71.2 °C</div>
                <div style="font-size:11px; color:var(--accent-green); font-weight:600;">Drop: 11.2°C (Healthy)</div>
              </div>
            </div>

            <div style="padding:12px; background:#F0FDF4; border-radius:var(--radius-sm); border:1px solid #BBF7D0; font-size:12px; color:#166534;">
              ✅ <strong>FSSAI Safety Standard Verified:</strong> Cooked food delivered in insulated containers maintains hot core > 65°C for up to 4 hours post-dispatch.
            </div>
          </div>
        </div>

        <!-- Food Shortage Reporting Section -->
        <div class="card" id="shortage-section" style="border-top:4px solid var(--status-amber);">
          <div class="card-header">
            <div>
              <h3 class="card-title">⚠️ Route Food Shortage Reporting Module</h3>
              <p style="font-size:13px; color:var(--text-secondary); margin-top:2px;">
                Toggle shortage toggle if student attendance exceeded expected supply or vessel spilled. Auto-calculates kg and %.
              </p>
            </div>
            <span class="badge badge-amber">Instant Supervisor Alert</span>
          </div>

          <form id="shortage-form" onsubmit="event.preventDefault(); AkshayaDriverView.submitShortage();">
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:16px;">
              <div class="form-group">
                <label class="form-label">School with Shortage</label>
                <select class="form-select" id="sht-school" required>
                  <option value="">-- Choose School --</option>
                  <option value="S1">Govt Higher Primary School, Malleshwaram</option>
                  <option value="S2" selected>Dr. B.R. Ambedkar Model School, Yeshwanthpur</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Item Shortage</label>
                <select class="form-select" id="sht-item" required>
                  <option value="Rice">Fortified Sona Masoori Rice</option>
                  <option value="Sambar" selected>Vegetable Dal Sambar</option>
                  <option value="Pongal">Sweet Pongal / Dessert</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Expected Quantity (kg)</label>
                <input type="number" step="0.1" class="form-input" id="sht-expected" value="460.0" oninput="AkshayaDriverView.calcShortage()" required>
              </div>

              <div class="form-group">
                <label class="form-label">Actual Quantity Available (kg)</label>
                <input type="number" step="0.1" class="form-input" id="sht-actual" value="442.0" oninput="AkshayaDriverView.calcShortage()" required>
              </div>
            </div>

            <!-- Auto-Calculated Metrics Box -->
            <div style="display:flex; gap:16px; background:#FFFBEB; padding:14px; border-radius:var(--radius-sm); border:1px solid #FDE68A; margin-bottom:16px; flex-wrap:wrap;">
              <div>
                <span style="font-size:12px; color:#92400E; display:block;">Calculated Shortage:</span>
                <strong id="disp-shortage-kg" style="font-size:20px; color:#B45309;">18.0 kg</strong>
              </div>
              <div style="border-left:1px solid #FCD34D; padding-left:16px;">
                <span style="font-size:12px; color:#92400E; display:block;">Shortage Percentage:</span>
                <strong id="disp-shortage-pct" style="font-size:20px; color:#B45309;">3.91 %</strong>
              </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:16px; margin-bottom:16px;">
              <div class="form-group">
                <label class="form-label">Reason for Shortage</label>
                <select class="form-select" id="sht-reason" required>
                  <option value="Extra Enrollments Today">Surge in Student Attendance (> enrolled)</option>
                  <option value="Gasket Leak / Spillage">Transit Spillage / Vessel Gasket Fault</option>
                  <option value="Kitchen Portion Miscount">Kitchen Packaging Portion Discrepancy</option>
                  <option value="Other">Other Operational Factor</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Photo Evidence (Live Camera / Vessel)</label>
                <input type="file" accept="image/*" class="form-input" id="sht-photo">
              </div>
            </div>

            <button type="submit" class="btn btn-primary" style="background:#D97706;">
              ⚠️ Dispatch Emergency Shortage Report
            </button>
          </form>
        </div>
      </div>
    `;
  },

  calcShortage: function() {
    var exp = parseFloat(document.getElementById('sht-expected').value) || 0;
    var act = parseFloat(document.getElementById('sht-actual').value) || 0;
    var diff = Math.max(0, exp - act);
    var pct = exp > 0 ? ((diff / exp) * 100).toFixed(2) : '0.00';

    document.getElementById('disp-shortage-kg').innerText = diff.toFixed(1) + ' kg';
    document.getElementById('disp-shortage-pct').innerText = pct + ' %';
  },

  submitShortage: function() {
    var exp = parseFloat(document.getElementById('sht-expected').value) || 0;
    var act = parseFloat(document.getElementById('sht-actual').value) || 0;
    var diff = Math.max(0, exp - act);
    var pct = exp > 0 ? ((diff / exp) * 100).toFixed(2) : '0.00';
    var school = document.getElementById('sht-school').value;
    var reason = document.getElementById('sht-reason').value;

    var record = {
      id: "SHT-" + Date.now().toString().substr(-5),
      timestamp: new Date().toLocaleTimeString(),
      school: school,
      expectedKg: exp,
      actualKg: act,
      shortageKg: diff,
      shortagePercent: pct,
      reason: reason
    };

    window.AkshayaSync.broadcast('SHORTAGE_REPORTED', record);
    window.AkshayaNotify.toast(`Shortage Alert Submitted: ${diff} kg (${pct}%). Supervisor Anand Rao notified for buffer supply.`, "warning");
  },

  scrollToShortage: function() {
    var el = document.getElementById('shortage-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  },

  showThermalLog: function() {
    window.AkshayaNotify.alertModal(
      "🌡️ Vehicle Temperature Log",
      `Vehicle KA-01-MJ-4521:\n09:30 AM: Dispatch (82.4°C)\n10:45 AM: Mid-route (76.8°C)\n11:42 AM: Stop 1 Arrival (74.0°C)\n11:58 AM: Stop 2 Arrival (71.2°C)\nAll points compliant with WHO/FSSAI mid-day meal guidelines.`
    );
  }
};
