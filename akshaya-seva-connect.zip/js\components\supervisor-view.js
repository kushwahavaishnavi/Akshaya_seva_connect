// Kitchen Supervisor Interface: Daily Report Approval, Weekly Hygiene Audit & Taste Log
window.AkshayaSupervisorView = {
  activeSubTab: 'reports',

  render: function() {
    var reports = window.AkshayaData.dailyReports;
    var audits = window.AkshayaData.hygieneAudits;
    var tasteLogs = window.AkshayaData.tasteLogs;

    return `
      <div class="single-panel-layout">
        <!-- Supervisor Banner -->
        <div class="card" style="background: linear-gradient(135deg, #FFF5EB 0%, #FFFFFF 100%); border-left: 5px solid var(--primary-saffron);">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:var(--primary-saffron); color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                📋
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">Anand Rao</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span class="badge badge-saffron">Area Supervisor</span>
                  <span>📍 Bengaluru Central Hub & North Cluster</span>
                  <span class="badge badge-green">3 Routes | 18 Staff</span>
                </div>
              </div>
            </div>

            <div style="display:flex; gap:10px;">
              <button class="btn btn-outline" onclick="AkshayaSupervisorView.showAddAuditModal()">
                ➕ Conduct Weekly Audit
              </button>
              <button class="btn btn-primary" onclick="AkshayaSupervisorView.showAddTasteLogModal()">
                🍲 Log Quality Taste Test
              </button>
            </div>
          </div>
        </div>

        <!-- Sub Tabs -->
        <div style="display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
          <button class="btn ${this.activeSubTab === 'reports' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaSupervisorView.setSubTab('reports')">
            📑 Daily Operations Reports (${reports.length})
          </button>
          <button class="btn ${this.activeSubTab === 'audits' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaSupervisorView.setSubTab('audits')">
            🧼 Weekly Hygiene Audits (0-100 Score)
          </button>
          <button class="btn ${this.activeSubTab === 'taste' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaSupervisorView.setSubTab('taste')">
            🥄 Food Quality & Sample Log
          </button>
        </div>

        <!-- Active View -->
        ${this.activeSubTab === 'reports' ? this.renderReportsList(reports) : ''}
        ${this.activeSubTab === 'audits' ? this.renderAuditsList(audits) : ''}
        ${this.activeSubTab === 'taste' ? this.renderTasteLogsList(tasteLogs) : ''}
      </div>
    `;
  },

  setSubTab: function(tab) {
    this.activeSubTab = tab;
    if (window.renderApp) window.renderApp();
  },

  renderReportsList: function(reports) {
    return `
      <div style="display:flex; flex-direction:column; gap:16px;">
        ${reports.map(rep => `
          <div class="card" style="border-left: 4px solid ${rep.status === 'Approved' ? 'var(--accent-green)' : 'var(--primary-saffron)'};">
            <div class="card-header">
              <div>
                <h3 class="card-title">${rep.kitchenName}</h3>
                <div style="font-size:12px; color:var(--text-secondary); margin-top:3px;">
                  Report ID: <strong>${rep.id}</strong> | Date: ${rep.date} | Route: ${rep.route}
                </div>
              </div>
              <div style="display:flex; gap:8px; align-items:center;">
                <span class="badge ${rep.status === 'Approved' ? 'badge-green' : 'badge-amber'}">
                  ${rep.status}
                </span>
                <span class="badge ${rep.submittedToHQ ? 'badge-navy' : 'badge-saffron'}">
                  HQ: ${rep.hqStatus}
                </span>
              </div>
            </div>

            <!-- Report Details Grid -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px; background:#F8FAFC; padding:14px; border-radius:var(--radius-sm); margin-bottom:14px; font-size:13px;">
              <div><strong>Children Fed:</strong> ${rep.childrenFed} / ${rep.enrolledTotal} enrolled</div>
              <div><strong>Total Food:</strong> ${rep.totalFoodKg} kg</div>
              <div><strong>Dispatch / Arrival:</strong> ${rep.dispatchTime} → ${rep.arrivalTime} (${rep.delayMinutes} min delay)</div>
              <div><strong>Core Temp:</strong> ${rep.tempDispatch} (Dispatch) / ${rep.tempArrival} (Arrival)</div>
              <div><strong>Driver:</strong> ${rep.driverName} (${rep.vehicleNo})</div>
              <div><strong>Food Wastage:</strong> ${rep.wasteKg} kg</div>
            </div>

            <div style="font-size:13px; color:var(--text-secondary); margin-bottom:14px;">
              <strong>Menu Served:</strong> ${rep.menuServed}
            </div>

            ${rep.shortageToggle ? `
              <div style="padding:10px 14px; background:#FEF3C7; border-radius:var(--radius-sm); border:1px solid #FCD34D; font-size:13px; color:#92400E; margin-bottom:14px;">
                ⚠️ <strong>Shortage Flagged:</strong> ${rep.shortageAmountKg} kg (${rep.shortagePercent}%) | Reason: ${rep.shortageReason}
              </div>
            ` : ''}

            <div style="font-size:13px; color:var(--accent-navy); background:#F1F5F9; padding:10px; border-radius:var(--radius-sm); margin-bottom:14px;">
              <strong>Supervisor Remarks:</strong> ${rep.supervisorRemarks || 'None entered'}
            </div>

            <!-- Workflow Approval Buttons -->
            <div style="display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap;">
              ${rep.status !== 'Approved' ? `
                <button class="btn btn-outline" style="border-color:var(--status-red); color:var(--status-red);" onclick="AkshayaSupervisorView.rejectReport('${rep.id}')">
                  ❌ Request Correction
                </button>
                <button class="btn btn-success" onclick="AkshayaSupervisorView.approveReport('${rep.id}')">
                  ✅ Approve Daily Report
                </button>
              ` : `
                <span style="font-size:12px; color:var(--accent-green); display:flex; align-items:center; gap:6px;">
                  ✓ Approved by ${rep.approvedBy}
                </span>
              `}

              ${!rep.submittedToHQ && rep.status === 'Approved' ? `
                <button class="btn btn-primary" onclick="AkshayaSupervisorView.submitToHQ('${rep.id}')">
                  🚀 Submit Approved Report to HQ
                </button>
              ` : ''}
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  renderAuditsList: function(audits) {
    return `
      <div style="display:flex; flex-direction:column; gap:20px;">
        ${audits.map(aud => `
          <div class="card">
            <div class="card-header">
              <div>
                <h3 class="card-title">Week ${aud.week} - Kitchen Audit (${aud.kitchenId})</h3>
                <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">
                  Audited by: ${aud.auditor} | Date: ${aud.date}
                </div>
              </div>
              <div style="display:flex; align-items:center; gap:10px;">
                <div style="text-align:right;">
                  <span style="font-size:24px; font-weight:700; color:${aud.rating === 'Green' ? '#16A34A' : (aud.rating === 'Amber' ? '#D97706' : '#DC2626')};">
                    ${aud.score} / 100
                  </span>
                  <div style="font-size:11px; text-transform:uppercase; font-weight:600; color:var(--text-secondary);">
                    Hygiene Rating: ${aud.rating}
                  </div>
                </div>
              </div>
            </div>

            <!-- Audit Checklist Table -->
            <div style="overflow-x:auto; margin-bottom:16px;">
              <table style="width:100%; border-collapse:collapse; font-size:13px; text-align:left;">
                <thead>
                  <tr style="background:#F8FAFC; border-bottom:2px solid var(--border-color);">
                    <th style="padding:10px;">Sanitation & Safety Area</th>
                    <th style="padding:10px; width:90px;">Compliance</th>
                    <th style="padding:10px;">Photo Evidence</th>
                    <th style="padding:10px;">Auditor Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  ${aud.checklist.map(item => `
                    <tr style="border-bottom:1px solid var(--border-color);">
                      <td style="padding:10px; font-weight:500;">${item.area}</td>
                      <td style="padding:10px;">
                        <span class="badge ${item.status === 'Yes' ? 'badge-green' : (item.status === 'No' ? 'badge-red' : 'badge-navy')}">
                          ${item.status}
                        </span>
                      </td>
                      <td style="padding:10px; color:#2563EB;">
                        ${item.photo ? `📷 [${item.photo}]` : '—'}
                      </td>
                      <td style="padding:10px; color:var(--text-secondary);">${item.remarks}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>

            <!-- Corrective Actions Table -->
            <div style="background:#FFFBEB; padding:14px; border-radius:var(--radius-sm); border:1px solid #FDE68A;">
              <h4 style="font-size:14px; color:#92400E; margin-bottom:8px;">🛠️ Corrective Actions & Deadlines</h4>
              ${aud.correctiveActions.map(ca => `
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:13px; padding:6px 0; border-bottom:1px dashed #FCD34D;">
                  <div>
                    <strong>[${ca.id}]</strong> ${ca.task}
                    <div style="font-size:11px; color:#B45309;">Assignee: ${ca.assignee} | Due: ${ca.deadline}</div>
                  </div>
                  <span class="badge ${ca.status === 'Closed' || ca.status === 'Resolved' ? 'badge-green' : 'badge-amber'}">
                    ${ca.status}
                  </span>
                </div>
              `).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  renderTasteLogsList: function(tasteLogs) {
    return `
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
        ${tasteLogs.map(tl => `
          <div class="card">
            <div class="card-header">
              <div>
                <h3 class="card-title">🥄 ${tl.dish}</h3>
                <div style="font-size:12px; color:var(--text-secondary);">
                  Tested by: ${tl.testedBy} | ${tl.time}
                </div>
              </div>
              <span class="badge badge-green">${tl.status}</span>
            </div>

            <div style="display:flex; flex-direction:column; gap:10px; font-size:13px; margin-bottom:14px;">
              <div><strong>Core Cooking Temperature:</strong> <span style="color:#C2410C; font-weight:700;">${tl.temperature}</span></div>
              <div><strong>Taste & Organoleptic Score:</strong> ${tl.tasteScore}</div>
              <div><strong>Salt / Sodium Level:</strong> ${tl.saltLevel}</div>
              <div><strong>Texture & Consistency:</strong> ${tl.texture}</div>
              <div><strong>Retained 48h Sample Cup ID:</strong> <span style="font-family:monospace; background:#E2E8F0; padding:2px 6px; border-radius:4px;">${tl.sampleRetainedCupId}</span></div>
            </div>

            <div style="background:#F1F5F9; border-radius:var(--radius-sm); height:110px; display:flex; align-items:center; justify-content:center; color:#475569; font-size:12px;">
              📷 [Retained Sample Cup Photo: ${tl.samplePhoto}]
            </div>
          </div>
        `).join('')}
      </div>
    `;
  },

  approveReport: function(repId) {
    var rep = window.AkshayaData.dailyReports.find(r => r.id === repId);
    if (!rep) return;
    rep.status = 'Approved';
    rep.approvedBy = 'Anand Rao (Area Supervisor)';
    rep.approvedAt = new Date().toISOString();

    window.AkshayaSync.broadcast('REPORT_APPROVED', { reportId: repId, approvedBy: rep.approvedBy });
    window.AkshayaNotify.toast(`Daily Operations Report #${repId} officially Approved!`, "success");
    if (window.renderApp) window.renderApp();
  },

  rejectReport: function(repId) {
    window.AkshayaNotify.alertModal(
      "❌ Request Report Clarification",
      `Report #${repId} flagged for correction. Note sent back to dispatch clerk to verify weigh-scale discrepancy.`
    );
  },

  submitToHQ: function(repId) {
    var rep = window.AkshayaData.dailyReports.find(r => r.id === repId);
    if (!rep) return;
    rep.submittedToHQ = true;
    rep.hqStatus = 'Pending Review';

    window.AkshayaData.hqInbox.unshift({
      id: "HQ-" + rep.id,
      reportId: rep.id,
      kitchenName: rep.kitchenName,
      submittedBy: "Anand Rao (Supervisor)",
      submittedAt: new Date().toISOString(),
      totalFed: rep.childrenFed,
      onTimeDeliveryRate: "100%",
      shortageRate: "0.0%",
      hygieneScore: 94,
      status: "Under Review",
      isNew: true
    });

    window.AkshayaSync.broadcast('REPORT_SUBMITTED_HQ', rep);
    window.AkshayaNotify.toast(`Report #${repId} successfully transmitted to Headquarters!`, "success");
    if (window.renderApp) window.renderApp();
  },

  showAddAuditModal: function() {
    window.AkshayaNotify.alertModal(
      "🧼 Conduct Weekly Hygiene Audit",
      `New Audit Wizard initialized:\n- 9 Mandatory Inspection Points\n- Live Camera Capture for Each Point\n- Auto Scoring Engine (0-100)\n- Corrective Action Assignment\n\n[Audit template opened]`
    );
  },

  showAddTasteLogModal: function() {
    window.AkshayaNotify.alertModal(
      "🍲 Food Quality & Taste Test",
      `Taste sample testing protocol:\n1. Calibrated probe thermometer check (>80°C)\n2. Palatability & salt percentage\n3. Retained sterile sample container sealed for 48 hours.\n\n[Record saved to FSSAI compliance register]`
    );
  }
};
