// Supplier Interface: Raw Material Delivery Entry, Batch QC & Supplier Scorecard
window.AkshayaSupplierView = {
  render: function() {
    var supplier = window.AkshayaData.suppliers[0]; // Annapurna Agro Grain

    return `
      <div class="single-panel-layout">
        <!-- Supplier Header -->
        <div class="card" style="background: linear-gradient(135deg, #FFFBEB 0%, #FFFFFF 100%); border-left: 5px solid #D97706;">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:#D97706; color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                🌾
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">${supplier.name}</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span class="badge badge-saffron">Category: ${supplier.category}</span>
                  <span>📍 ${supplier.location}</span>
                  <span class="badge badge-green">FSSAI Certified Tier-1</span>
                </div>
              </div>
            </div>

            <div style="text-align:right;">
              <div style="font-size:26px; font-weight:700; color:#16A34A;">${supplier.rating}%</div>
              <div style="font-size:12px; color:var(--text-secondary); font-weight:600;">Quality & Delivery Score</div>
            </div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          <!-- New Raw Material Inward Entry Form -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">📦 New Raw Material Inward Entry</h3>
              <span class="badge badge-navy">Direct to Kitchen Gate</span>
            </div>

            <form onsubmit="event.preventDefault(); AkshayaSupplierView.submitDelivery();">
              <div class="form-group">
                <label class="form-label">Receiving Kitchen Hub</label>
                <select class="form-select" id="sup-kitchen" required>
                  <option value="K1">Bengaluru Central Mega Kitchen</option>
                  <option value="K2">Hubballi Industrial Kitchen</option>
                  <option value="K3">Mysuru Rural Cluster Kitchen</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Commodity & Grade</label>
                <input type="text" class="form-input" id="sup-item" value="Fortified Sona Masoori Raw Rice (Grade A)" required>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div class="form-group">
                  <label class="form-label">Quantity (kg)</label>
                  <input type="number" class="form-input" id="sup-qty" value="5000" required>
                </div>

                <div class="form-group">
                  <label class="form-label">Batch / Lot Number</label>
                  <input type="text" class="form-input" id="sup-batch" value="BATCH-2026-OCT-901" required>
                </div>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div class="form-group">
                  <label class="form-label">Mfg / Milling Date</label>
                  <input type="date" class="form-input" id="sup-mfg" value="2026-10-15" required>
                </div>

                <div class="form-group">
                  <label class="form-label">Best Before / Expiry</label>
                  <input type="date" class="form-input" id="sup-exp" value="2027-04-15" required>
                </div>
              </div>

              <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div class="form-group">
                  <label class="form-label">Moisture Content (%)</label>
                  <input type="text" class="form-input" id="sup-moisture" value="11.4%">
                </div>

                <div class="form-group">
                  <label class="form-label">FSSAI NABL Lab Report</label>
                  <input type="file" class="form-input">
                </div>
              </div>

              <button type="submit" class="btn btn-primary" style="width:100%;">
                📋 Submit Material Delivery Entry
              </button>
            </form>
          </div>

          <!-- Recent Deliveries & QC Log -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">📜 Recent Inward Deliveries & QC Verification</h3>
              <span class="badge badge-green">100% Traceability</span>
            </div>

            <div style="display:flex; flex-direction:column; gap:14px;">
              ${window.AkshayaData.suppliers.map(s => `
                <div style="background:#F8FAFC; border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:12px;">
                  <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:4px;">
                    <strong style="color:var(--accent-navy); font-size:14px;">${s.name}</strong>
                    <span class="badge badge-green">${s.status}</span>
                  </div>
                  <div style="font-size:12px; color:var(--text-secondary); margin-bottom:6px;">
                    Category: ${s.category} | Rating: <strong>${s.rating}%</strong>
                  </div>
                  ${s.recentDeliveries.map(d => `
                    <div style="font-size:12px; background:#FFFFFF; padding:8px; border-radius:4px; border-left:3px solid var(--accent-green); margin-top:4px;">
                      <div><strong>${d.item}</strong> (${d.quantityKg} kg)</div>
                      <div style="color:var(--text-muted); font-size:11px;">Batch: ${d.batchNo} | QC: <span style="color:#16A34A; font-weight:600;">${d.qcStatus}</span></div>
                    </div>
                  `).join('')}
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  },

  submitDelivery: function() {
    var item = document.getElementById('sup-item').value;
    var qty = document.getElementById('sup-qty').value;
    var batch = document.getElementById('sup-batch').value;

    window.AkshayaNotify.toast(`Delivery Entry logged: ${qty} kg of ${item} (Batch: ${batch}). Gate pass generated!`, "success");
  }
};
