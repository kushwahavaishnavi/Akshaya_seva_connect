// Public & Staff Complaint, SLA Tracker & Emergency SOS Portal
window.AkshayaComplaintView = {
  currentTab: 'raise', // 'raise', 'track'
  isRecordingVoice: false,

  render: function() {
    var complaints = window.AkshayaData.complaints;

    return `
      <div class="single-panel-layout">
        <!-- Complaint Banner -->
        <div class="card" style="background: linear-gradient(135deg, #FFF1F2 0%, #FFFFFF 100%); border-left: 5px solid var(--status-red);">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:16px;">
            <div style="display:flex; align-items:center; gap:16px;">
              <div style="width:68px; height:68px; border-radius:var(--radius-md); background:var(--status-red); color:#FFF; display:flex; align-items:center; justify-content:center; font-size:32px;">
                📢
              </div>
              <div>
                <h2 style="font-size:22px; color:var(--accent-navy); margin-bottom:2px;">Public Grievance & Quality Feedback Portal</h2>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; font-size:13px; color:var(--text-secondary);">
                  <span>Zero Login Required for Citizens & Parents</span>
                  <span class="badge badge-navy">Strict SLA Enforcement</span>
                  <span class="badge badge-red">Critical Alerts Monitored 24/7</span>
                </div>
              </div>
            </div>

            <div style="display:flex; gap:10px;">
              <button class="btn btn-danger" onclick="AkshayaDemoBar.simulateCriticalComplaint()">
                🚨 EMERGENCY SOS
              </button>
            </div>
          </div>
        </div>

        <!-- Sub Tabs -->
        <div style="display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:8px;">
          <button class="btn ${this.currentTab === 'raise' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaComplaintView.setTab('raise')">
            ✍️ Raise a Grievance / Feedback
          </button>
          <button class="btn ${this.currentTab === 'track' ? 'btn-primary' : 'btn-outline'}" onclick="AkshayaComplaintView.setTab('track')">
            🔍 Track Complaint Status (Ticket ID)
          </button>
        </div>

        <!-- Body -->
        ${this.currentTab === 'raise' ? this.renderRaiseForm() : this.renderTrackView(complaints)}
      </div>
    `;
  },

  setTab: function(tab) {
    this.currentTab = tab;
    if (window.renderApp) window.renderApp();
  },

  renderRaiseForm: function() {
    return `
      <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
        <!-- Left: Form -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📝 Register New Complaint</h3>
            <span class="badge badge-saffron">Instant SMS & WhatsApp Updates</span>
          </div>

          <form id="raise-complaint-form" onsubmit="event.preventDefault(); AkshayaComplaintView.submitNewComplaint();">
            <div class="form-group">
              <label class="form-label">Category of Issue</label>
              <select class="form-select" id="cmp-category" onchange="AkshayaComplaintView.handleCategoryChange(this.value)" required>
                <option value="Food Quality">Food Quality & Taste (Under-cooked, excess spice, cold)</option>
                <option value="Food Quantity">Food Quantity Shortage (Not enough for all students)</option>
                <option value="Hygiene & Sanitation">Hygiene & Cleanliness (Utensils, transport van, staff PPE)</option>
                <option value="Delivery Delay">Delivery Delay (Arrived late after scheduled lunch bell)</option>
                <option value="Critical / Foreign Object" style="color:red; font-weight:700;">🚨 Critical Safety: Foreign Object / Health Concern</option>
                <option value="Staff Behaviour">Staff / Driver Behaviour</option>
                <option value="Other">Other / General Suggestion</option>
              </select>
            </div>

            <div id="critical-warning-box" style="display:none; padding:12px; background:#FEF2F2; border:1px solid #F87171; border-radius:var(--radius-sm); margin-bottom:14px; color:#991B1B; font-size:13px;">
              ⚠️ <strong>Critical Safety Protocol Triggered:</strong> Selecting this priority instantly triggers SMS & push notifications to State HQ, Area Supervisor and pauses batch distribution pending inspection!
            </div>

            <div class="form-group">
              <label class="form-label">Detailed Description</label>
              <textarea class="form-textarea" id="cmp-desc" rows="4" placeholder="Please mention exact school name, dish, timing, and what happened..." required></textarea>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
              <div class="form-group">
                <label class="form-label">Your Name (Optional)</label>
                <input type="text" class="form-input" id="cmp-name" placeholder="Leave blank if anonymous">
              </div>

              <div class="form-group">
                <label class="form-label">Phone / WhatsApp (For updates)</label>
                <input type="tel" class="form-input" id="cmp-phone" placeholder="+91 98XXX XXXXX">
              </div>
            </div>

            <!-- Media Attachments -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:16px;">
              <div class="form-group">
                <label class="form-label">Attach Photo Evidence</label>
                <input type="file" accept="image/*" class="form-input" id="cmp-photo">
              </div>

              <div class="form-group">
                <label class="form-label">Voice Note (For Low-Literacy Users)</label>
                <button type="button" class="btn btn-outline" id="btn-record-voice" onclick="AkshayaComplaintView.toggleVoiceRecord()" style="width:100%;">
                  🎙️ Record Voice Note (Hold)
                </button>
              </div>
            </div>

            <div class="form-group" style="display:flex; align-items:center; gap:8px;">
              <input type="checkbox" id="cmp-anon" style="width:18px; height:18px;">
              <label for="cmp-anon" style="font-size:13px; color:var(--text-secondary); cursor:pointer;">
                Submit Anonymously (Do not reveal my phone or identity to field staff)
              </label>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%; font-size:15px; padding:12px;">
              🚀 Submit Grievance & Generate Ticket
            </button>
          </form>
        </div>

        <!-- Right: Public Service Commitment & SLA -->
        <div>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">⏱️ Service Level Agreement (SLA) Matrix</h3>
              <span class="badge badge-green">Citizen Charter</span>
            </div>

            <div style="display:flex; flex-direction:column; gap:12px; font-size:13px;">
              <div style="padding:10px; background:#FEF2F2; border-radius:var(--radius-sm); border-left:4px solid var(--status-red);">
                <strong style="color:#991B1B;">Critical Safety / Foreign Object:</strong><br>
                Instant escalation. On-site inspection within <strong>60 minutes</strong>.
              </div>

              <div style="padding:10px; background:#FFFBEB; border-radius:var(--radius-sm); border-left:4px solid var(--status-amber);">
                <strong style="color:#92400E;">Food Shortage / Transit Delay:</strong><br>
                Buffer dispatch within <strong>30 minutes</strong>; corrective action closed in 24 hours.
              </div>

              <div style="padding:10px; background:#F0FDF4; border-radius:var(--radius-sm); border-left:4px solid var(--accent-green);">
                <strong style="color:#166534;">Taste / Menu Feedback:</strong><br>
                Dietitian review & portion adjustment within <strong>48 hours</strong>.
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  renderTrackView: function(complaints) {
    return `
      <div>
        <!-- Search bar -->
        <div class="card" style="margin-bottom:20px;">
          <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <input type="text" id="track-search-input" class="form-input" style="flex:1; min-width:240px;" placeholder="Enter Ticket ID (e.g. TKT-2026-0999) or Phone Number...">
            <button class="btn btn-primary" onclick="AkshayaComplaintView.searchTicket()">
              🔍 Search Ticket
            </button>
          </div>
        </div>

        <!-- Complaints Tracker List -->
        <div style="display:flex; flex-direction:column; gap:16px;">
          ${complaints.map(tkt => `
            <div class="card" style="border-left: 4px solid ${tkt.priority === 'Critical' ? 'var(--status-red)' : (tkt.priority === 'High' ? 'var(--status-amber)' : 'var(--accent-navy)')};">
              <div class="card-header">
                <div>
                  <div style="display:flex; align-items:center; gap:8px;">
                    <h3 class="card-title">${tkt.id}</h3>
                    <span class="badge ${tkt.priority === 'Critical' ? 'badge-red' : (tkt.priority === 'High' ? 'badge-amber' : 'badge-navy')}">
                      Priority: ${tkt.priority}
                    </span>
                  </div>
                  <div style="font-size:12px; color:var(--text-secondary); margin-top:2px;">
                    Raised: ${new Date(tkt.date).toLocaleString()} | Complainant: ${tkt.isAnonymous ? 'Anonymous Citizen' : tkt.complainantName}
                  </div>
                </div>

                <div style="text-align:right;">
                  <span class="badge ${tkt.status === 'Resolved' ? 'badge-green' : (tkt.status === 'Open' ? 'badge-red' : 'badge-amber')}" style="font-size:13px;">
                    Status: ${tkt.status}
                  </span>
                  <div style="font-size:11px; color:#DC2626; font-weight:600; margin-top:4px;">
                    SLA Deadline: ${new Date(tkt.slaDeadline).toLocaleTimeString()}
                  </div>
                </div>
              </div>

              <!-- Ticket Content -->
              <p style="font-size:14px; color:var(--text-primary); margin-bottom:14px; background:#F8FAFC; padding:12px; border-radius:var(--radius-sm);">
                <strong>Category:</strong> ${tkt.category}<br>
                <strong>School / Center:</strong> ${tkt.schoolName}<br>
                <strong>Grievance Description:</strong> ${tkt.description}
              </p>

              <!-- Live Resolution SLA Progress Bar -->
              <div style="margin-bottom:14px;">
                <div style="display:flex; justify-content:space-between; font-size:11px; font-weight:600; color:var(--text-secondary); margin-bottom:4px;">
                  <span>1. Open</span>
                  <span>2. Assigned</span>
                  <span>3. In Progress</span>
                  <span>4. Resolved</span>
                  <span>5. Closed</span>
                </div>
                <div style="width:100%; height:8px; background:#E2E8F0; border-radius:4px; overflow:hidden;">
                  <div style="height:100%; width:${tkt.status === 'Resolved' ? '100%' : (tkt.status === 'In Progress' ? '60%' : (tkt.status === 'Assigned' ? '40%' : '20%'))}; background:${tkt.status === 'Resolved' ? '#16A34A' : '#F28C28'}; transition:width 0.3s;"></div>
                </div>
              </div>

              <div style="display:flex; justify-content:space-between; align-items:center; font-size:12px; color:var(--text-secondary); flex-wrap:wrap; gap:8px;">
                <div>
                  <strong>Assigned Custodian:</strong> ${tkt.assignedTo}
                </div>
                ${tkt.resolutionNotes ? `
                  <div style="color:var(--accent-green); font-weight:600;">
                    ✓ Resolution: ${tkt.resolutionNotes}
                  </div>
                ` : `
                  <div style="color:#D97706; font-weight:600;">
                    ⏳ Field Investigation Underway
                  </div>
                `}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  handleCategoryChange: function(val) {
    var warnBox = document.getElementById('critical-warning-box');
    if (warnBox) {
      warnBox.style.display = val === 'Critical / Foreign Object' ? 'block' : 'none';
    }
  },

  toggleVoiceRecord: function() {
    var btn = document.getElementById('btn-record-voice');
    if (!this.isRecordingVoice) {
      this.isRecordingVoice = true;
      btn.innerHTML = '🔴 Recording... Speak Now (Click to Stop)';
      btn.style.borderColor = '#DC2626';
      btn.style.color = '#DC2626';
      window.AkshayaNotify.toast("Voice note recording started (Audio assistance enabled)", "warning");
    } else {
      this.isRecordingVoice = false;
      btn.innerHTML = '✅ Voice Note Captured (14s audio attached)';
      btn.style.borderColor = '#16A34A';
      btn.style.color = '#16A34A';
      window.AkshayaNotify.toast("Voice note attached to grievance!", "success");
    }
  },

  submitNewComplaint: function() {
    var cat = document.getElementById('cmp-category').value;
    var desc = document.getElementById('cmp-desc').value;
    var name = document.getElementById('cmp-name').value || 'Anonymous Citizen';
    var phone = document.getElementById('cmp-phone').value || '--';
    var isAnon = document.getElementById('cmp-anon').checked;
    var isCrit = cat.includes('Critical');

    var ticket = {
      id: "TKT-" + new Date().getFullYear() + "-" + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toISOString(),
      complainantName: isAnon ? 'Anonymous Citizen' : name,
      complainantPhone: isAnon ? '--' : phone,
      role: 'Public / Citizen',
      schoolName: 'Govt Model School, Bengaluru',
      kitchenId: 'K1',
      category: cat,
      priority: isCrit ? 'Critical' : 'Medium',
      description: desc,
      photo: null,
      voiceNote: this.isRecordingVoice ? 'voice_recording.wav' : null,
      isAnonymous: isAnon,
      status: 'Open',
      assignedTo: isCrit ? 'HQ Safety Cell & Anand Rao' : 'Area Supervisor Anand Rao',
      slaDeadline: new Date(Date.now() + (isCrit ? 3600000 : 86400000)).toISOString(),
      isCriticalAlert: isCrit
    };

    window.AkshayaData.complaints.unshift(ticket);
    window.AkshayaSync.broadcast('COMPLAINT_RAISED', ticket);

    if (isCrit) {
      window.AkshayaDemoBar.playEmergencyBeep();
      window.AkshayaNotify.alertModal(
        "🚨 CRITICAL GRIEVANCE SUBMITTED",
        `Ticket #${ticket.id} registered!\n\nDue to the critical nature of this complaint, automated SOS broadcasts have been sent to Area Supervisors, Food Safety Auditors, and the District Collector's Cell.`
      );
    } else {
      window.AkshayaNotify.toast(`Complaint #${ticket.id} registered! SMS tracking link sent to ${phone}`, "success");
    }

    this.setTab('track');
  },

  searchTicket: function() {
    var q = document.getElementById('track-search-input').value.trim();
    if (!q) {
      window.AkshayaNotify.toast("Please enter a ticket ID to search", "warning");
      return;
    }
    window.AkshayaNotify.toast(`Filtered tracking status for ticket query: ${q}`, "success");
  }
};
